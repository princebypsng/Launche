package com.sleek.launcher

import android.content.Context
import android.content.SharedPreferences

/** Which of the two profiles is active (device-wide). */
object Profiles {
    private fun sp(c: Context) = c.getSharedPreferences("sleek_global", Context.MODE_PRIVATE)
    fun active(c: Context): Int = sp(c).getInt("active", 0)
    fun set(c: Context, i: Int) = sp(c).edit().putInt("active", i).apply()
    fun suffix(i: Int) = if (i == 0) "" else "_p$i"
}

/** Per-profile settings. Profile 0 keeps the original file name so old settings carry over. */
class Prefs(ctx: Context, private val profile: Int = 0) {
    private val sp: SharedPreferences =
        ctx.getSharedPreferences(if (profile == 0) "sleek" else "sleek_p$profile", Context.MODE_PRIVATE)
    private fun put(f: (SharedPreferences.Editor) -> Unit) { val e = sp.edit(); f(e); e.apply() }

    var wallpaper: Int get() = sp.getInt("wp", if (profile == 0) 0 else 3); set(v) = put { it.putInt("wp", v) }   // -1 = custom photo
    var dim: Int get() = sp.getInt("dim", 40); set(v) = put { it.putInt("dim", v) }
    var accent: Int get() = sp.getInt("accent", if (profile == 0) 0 else 3); set(v) = put { it.putInt("accent", v) }
    var clock: Int get() = sp.getInt("clock", 0); set(v) = put { it.putInt("clock", v) }          // 0 auto, 1 12h, 2 24h
    var clockStyle: Int get() = sp.getInt("cstyle", 0); set(v) = put { it.putInt("cstyle", v) }
    var uiSize: Int get() = sp.getInt("ui", 1); set(v) = put { it.putInt("ui", v) }
    var cardSize: Int get() = sp.getInt("card", 1); set(v) = put { it.putInt("card", v) }
    var showNames: Boolean get() = sp.getBoolean("names", true); set(v) = put { it.putBoolean("names", v) }
    var showNonTv: Boolean get() = sp.getBoolean("nontv", true); set(v) = put { it.putBoolean("nontv", v) }
    var name: String get() = sp.getString("name", "") ?: ""; set(v) = put { it.putString("name", v) }

    val favorites: Set<String> get() = HashSet(sp.getStringSet("fav", emptySet()) ?: emptySet())

    fun toggleFavorite(key: String) {
        val s = favorites.toMutableSet()
        if (!s.remove(key)) s.add(key)
        put { it.putStringSet("fav", s) }
    }
}
