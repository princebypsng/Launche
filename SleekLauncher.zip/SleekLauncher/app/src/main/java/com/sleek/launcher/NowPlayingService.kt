package com.sleek.launcher

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import java.util.concurrent.Executors

/**
 * Needs "Notification access" (the user turns it on once). It does NOT read notification text: it only listens to
 * media sessions (what YouTube, Netflix, Nuvio... report as now playing) and remembers title, artwork and progress.
 */
class NowPlayingService : NotificationListenerService() {

    private val io = Executors.newSingleThreadExecutor()
    private val ctrls = HashMap<MediaSession.Token, MediaController>()
    private val cbs = HashMap<MediaSession.Token, MediaController.Callback>()
    private var msm: MediaSessionManager? = null
    private val me by lazy { ComponentName(this, NowPlayingService::class.java) }
    private val sessionsListener = MediaSessionManager.OnActiveSessionsChangedListener { list -> attach(list ?: emptyList()) }

    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            val m = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            msm = m
            m.addOnActiveSessionsChangedListener(sessionsListener, me)
            attach(m.getActiveSessions(me))
        } catch (e: SecurityException) { /* access not granted */ }
    }

    override fun onListenerDisconnected() {
        detachAll()
        try { msm?.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) { }
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        detachAll()
        super.onDestroy()
    }

    private fun detachAll() {
        for ((t, c) in ctrls) cbs[t]?.let { c.unregisterCallback(it) }
        ctrls.clear()
        cbs.clear()
    }

    private fun attach(list: List<MediaController>) {
        val live = list.map { it.sessionToken }
        for (t in ctrls.keys.toList()) {
            if (t !in live) {
                val c = ctrls.remove(t)
                val cb = cbs.remove(t)
                if (c != null && cb != null) c.unregisterCallback(cb)
            }
        }
        for (c in list) {
            val t = c.sessionToken
            if (ctrls.containsKey(t)) continue
            val cb = object : MediaController.Callback() {
                override fun onMetadataChanged(metadata: MediaMetadata?) { record(c) }
                override fun onPlaybackStateChanged(state: PlaybackState?) { record(c) }
            }
            ctrls[t] = c
            cbs[t] = cb
            c.registerCallback(cb)
            record(c)
        }
    }

    private fun isMusic(pkg: String): Boolean {
        val p = pkg.lowercase()
        return listOf("spotify", "music", "deezer", "tidal", "pandora", "soundcloud", "podcast", "audible").any { p.contains(it) }
    }

    private fun record(c: MediaController) {
        try {
            val pkg = c.packageName ?: return
            if (pkg == packageName) return
            val md = c.metadata ?: return
            val st = c.playbackState ?: return
            if (st.state == PlaybackState.STATE_NONE) return
            val title = (md.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: md.getString(MediaMetadata.METADATA_KEY_TITLE))
                ?.trim().orEmpty()
            if (title.isEmpty()) return
            val profile = Profiles.active(this)
            if (isMusic(pkg) && !Prefs(this, profile).showMusic) return
            val sub = (md.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: md.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM))?.trim().orEmpty()
            val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
            var pos = st.position
            if (st.state == PlaybackState.STATE_PLAYING) {
                pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
            }
            if (pos < 0) pos = 0
            val bmp = md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART)
                ?: md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            val uri = md.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI) ?: md.getString(MediaMetadata.METADATA_KEY_ART_URI)
                ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
            val key = "$pkg|${title.lowercase()}"
            val art = Integer.toHexString(key.hashCode()) + ".jpg"
            val appCtx = applicationContext
            io.execute {
                try {
                    val ok = WatchArt.store(appCtx, bmp, uri, art)
                    if (dur > 0 && pos >= dur * 0.95) {
                        WatchStore.remove(appCtx, profile, key)   // finished: drop it from Continue watching
                    } else {
                        WatchStore.upsert(appCtx, profile,
                            WatchItem(key, pkg, title, sub, if (ok) art else "", pos, dur, System.currentTimeMillis(), "", 0))
                    }
                } catch (e: Exception) { }
            }
        } catch (e: Exception) { }
    }
}
