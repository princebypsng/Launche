package com.sleek.launcher

import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/** "Continue watching" cards: artwork, title, app name and a progress bar. */
class WatchAdapter(
    private val items: List<WatchItem>,
    private val p: Prefs,
    private val accent: Int,
    private val onClick: (WatchItem) -> Unit,
    private val onLong: (WatchItem) -> Unit
) : RecyclerView.Adapter<WatchAdapter.VH>() {

    companion object { val W = intArrayOf(136, 168, 200) }

    private val labels = HashMap<String, String>()

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: FrameLayout = v.findViewById(R.id.card)
        val img: ImageView = v.findViewById(R.id.img)
        val track: View = v.findViewById(R.id.track)
        val fill: View = v.findViewById(R.id.fill)
        val title: TextView = v.findViewById(R.id.title)
        val sub: TextView = v.findViewById(R.id.sub)
        val ring = GradientDrawable()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context
        val h = VH(LayoutInflater.from(c).inflate(R.layout.item_watch, parent, false))
        val w = c.dp(W[p.cardSize].toFloat())
        h.card.layoutParams = LinearLayout.LayoutParams(w, w * 9 / 16)
        val r = c.dp(10f).toFloat()
        h.card.background = GradientDrawable().apply { cornerRadius = r; setColor(0x22FFFFFF) }
        h.ring.cornerRadius = r
        h.ring.setStroke(c.dp(2f), 0)
        h.card.foreground = h.ring
        roundClip(h.img, r)
        h.itemView.setOnFocusChangeListener { v, f ->
            val s = if (f) 1.06f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            h.ring.setStroke(c.dp(2f), if (f) accent else 0)
        }
        return h
    }

    override fun onBindViewHolder(h: VH, i: Int) {
        val w = items[i]
        val c = h.itemView.context
        val pm = c.packageManager
        val bmp = WatchArt.get(c, w.art)
        if (bmp != null) {
            h.img.setPadding(0, 0, 0, 0)
            h.img.scaleType = if (bmp.width.toFloat() / bmp.height >= 1.4f) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
            h.img.setImageBitmap(bmp)
        } else {
            val banner = try { pm.getApplicationBanner(w.pkg) } catch (e: Exception) { null }
            if (banner != null) {
                h.img.setPadding(0, 0, 0, 0)
                h.img.scaleType = ImageView.ScaleType.CENTER_CROP
                h.img.setImageDrawable(banner)
            } else {
                val pad = h.card.layoutParams.height / 5
                h.img.setPadding(pad, pad, pad, pad)
                h.img.scaleType = ImageView.ScaleType.FIT_CENTER
                h.img.setImageDrawable(try { pm.getApplicationIcon(w.pkg) } catch (e: Exception) { null })
            }
        }
        val app = labels.getOrPut(w.pkg) {
            try { pm.getApplicationLabel(pm.getApplicationInfo(w.pkg, 0)).toString() } catch (e: Exception) { w.pkg }
        }
        h.title.text = w.title
        h.sub.text = when {
            w.src == 2 -> "Recently opened"
            w.sub.isBlank() -> app
            else -> "$app · ${w.sub}"
        }
        val hasBar = w.dur > 0 && w.src != 2
        val frac = if (hasBar) (w.pos.toFloat() / w.dur).coerceIn(0f, 1f) else 0f
        h.track.visibility = if (hasBar) View.VISIBLE else View.GONE
        h.fill.visibility = if (hasBar && frac > 0f) View.VISIBLE else View.GONE
        h.fill.setBackgroundColor(accent)
        val full = h.card.layoutParams.width - c.dp(16f)
        h.fill.layoutParams = FrameLayout.LayoutParams(maxOf(c.dp(3f), (full * frac).toInt()), c.dp(3f), Gravity.BOTTOM or Gravity.START)
            .apply { marginStart = c.dp(8f); bottomMargin = c.dp(7f) }
        h.itemView.setOnClickListener { onClick(w) }
        h.itemView.setOnLongClickListener { onLong(w); true }
    }

    override fun getItemCount() = items.size
}
