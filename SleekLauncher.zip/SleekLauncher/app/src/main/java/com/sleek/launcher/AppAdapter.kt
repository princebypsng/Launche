package com.sleek.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File

/** An installed app, or (iconRes != 0) a built-in shortcut whose cn.className is a Settings action. */
data class AppItem(val label: String, val cn: ComponentName, val iconRes: Int = 0) {
    val key: String get() = cn.flattenToString()
}

/** Icons/banners are loaded lazily into a small LRU cache. A user-picked icon always wins. */
object Art {
    const val BANNER = 0
    const val ICON = 1
    const val CUSTOM = 2
    class Entry(val d: Drawable, val kind: Int)

    lateinit var iconDir: File
    private val cache = LruCache<String, Entry>(40)

    fun clear() = cache.evictAll()
    fun customFile(key: String) = File(iconDir, Integer.toHexString(key.hashCode()) + ".png")

    fun get(ctx: Context, cn: ComponentName, wantBanner: Boolean): Entry? {
        val key = cn.flattenToString()
        val ck = key + (if (wantBanner) "#b" else "#i")
        cache.get(ck)?.let { return it }
        var e: Entry? = null
        val cf = customFile(key)
        if (cf.exists()) BitmapFactory.decodeFile(cf.path)?.let { e = Entry(BitmapDrawable(ctx.resources, it), CUSTOM) }
        if (e == null) {
            try {
                val pm = ctx.packageManager
                val b = if (wantBanner) pm.getActivityBanner(cn) else null
                e = if (b != null) Entry(b, BANNER) else Entry(pm.getActivityIcon(cn), ICON)
            } catch (x: Exception) { /* app vanished */ }
        }
        e?.let { cache.put(ck, it) }
        return e
    }
}

class AppAdapter(
    private val items: List<AppItem>,
    private val p: Prefs,
    private val accent: Int,
    private val mode: Int,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    companion object {
        const val M_BANNER = 0   // 16:9 cards
        const val M_SQUARE = 1   // round-square tiles with label below
        const val M_SIDE = 2     // small round-square + label to the right (vertical sideline)
        val CARD_W = intArrayOf(104, 128, 152)
        val SQ = intArrayOf(80, 96, 116)
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: FrameLayout = v.findViewById(R.id.card)
        val img: ImageView = v.findViewById(R.id.img)
        val label: TextView = v.findViewById(R.id.label)
        val ring = GradientDrawable()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context
        val side = mode == M_SIDE
        val h = VH(LayoutInflater.from(c).inflate(if (side) R.layout.item_side else R.layout.item_app, parent, false))
        val w = c.dp(when (mode) { M_SIDE -> 56f; M_SQUARE -> SQ[p.cardSize].toFloat(); else -> CARD_W[p.cardSize].toFloat() })
        h.card.layoutParams = LinearLayout.LayoutParams(w, if (mode == M_BANNER) w * 9 / 16 else w)
        val r = if (mode == M_BANNER) c.dp(8f).toFloat() else w * 0.26f
        h.card.background = GradientDrawable().apply { cornerRadius = r; setColor(0x22FFFFFF) }
        h.ring.cornerRadius = r
        h.ring.setStroke(c.dp(2f), 0)
        h.card.foreground = h.ring
        roundClip(h.img, r)
        if (side) h.label.alpha = 0.75f
        h.itemView.setOnFocusChangeListener { v, f ->
            val s = if (f) 1.08f else 1f
            if (side) { v.pivotX = 0f; v.pivotY = v.height / 2f; h.label.alpha = if (f) 1f else 0.75f }
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            h.ring.setStroke(c.dp(2f), if (f) accent else 0)
        }
        return h
    }

    override fun onBindViewHolder(h: VH, i: Int) {
        val a = items[i]
        val c = h.itemView.context
        val shortcut = a.iconRes != 0
        val e = if (shortcut) null else Art.get(c, a.cn, mode == M_BANNER)
        val kind = if (shortcut) Art.ICON else (e?.kind ?: Art.ICON)
        val full = kind == Art.BANNER || (kind == Art.CUSTOM && mode != M_BANNER)
        val px = h.card.layoutParams.height
        val pad = if (full) 0 else (px * (if (shortcut) 0.27f else if (kind == Art.CUSTOM) 0.08f else 0.2f)).toInt()
        h.img.setPadding(pad, pad, pad, pad)
        h.img.scaleType = if (full) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        if (shortcut) h.img.setImageResource(a.iconRes)
        else h.img.setImageDrawable(e?.d?.constantState?.newDrawable() ?: e?.d)
        h.label.text = a.label
        h.label.visibility = if (mode == M_SIDE || p.showNames) View.VISIBLE else View.GONE
        h.itemView.setOnClickListener { onClick(a) }
        h.itemView.setOnLongClickListener { onLong(a); true }
    }

    override fun getItemCount() = items.size
}
