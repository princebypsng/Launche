package com.sleek.launcher

import android.content.ComponentName
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File

data class AppItem(val label: String, val cn: ComponentName) {
    val key: String get() = cn.flattenToString()
}

/** Icons/banners are loaded lazily into a small LRU cache. A user-picked icon always wins. */
object Art {
    const val BANNER = 0
    const val ICON = 1
    const val CUSTOM = 2
    class Entry(val d: Drawable, val kind: Int)

    lateinit var iconDir: File
    private val cache = LruCache<String, Entry>(40)

    fun clear() = cache.evictAll()
    fun customFile(key: String) = File(iconDir, Integer.toHexString(key.hashCode()) + ".png")

    fun get(ctx: Context, cn: ComponentName, wantBanner: Boolean): Entry? {
        val key = cn.flattenToString()
        val ck = key + (if (wantBanner) "#b" else "#i")
        cache.get(ck)?.let { return it }
        var e: Entry? = null
        val cf = customFile(key)
        if (cf.exists()) BitmapFactory.decodeFile(cf.path)?.let { e = Entry(BitmapDrawable(ctx.resources, it), CUSTOM) }
        if (e == null) {
            try {
                val pm = ctx.packageManager
                val b = if (wantBanner) pm.getActivityBanner(cn) else null
                e = if (b != null) Entry(b, BANNER) else Entry(pm.getActivityIcon(cn), ICON)
            } catch (x: Exception) { /* app vanished */ }
        }
        e?.let { cache.put(ck, it) }
        return e
    }
}

class AppAdapter(
    private val items: List<AppItem>,
    private val p: Prefs,
    private val accent: Int,
    private val square: Boolean,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    companion object {
        val CARD_W = intArrayOf(104, 128, 152)   // 16:9 cards
        val SQ = intArrayOf(88, 104, 124)        // square tiles
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: FrameLayout = v.findViewById(R.id.card)
        val img: ImageView = v.findViewById(R.id.img)
        val label: TextView = v.findViewById(R.id.label)
        val ring = GradientDrawable()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context
        val h = VH(LayoutInflater.from(c).inflate(R.layout.item_app, parent, false))
        val w = c.dp((if (square) SQ else CARD_W)[p.cardSize].toFloat())
        h.card.layoutParams = LinearLayout.LayoutParams(w, if (square) w else w * 9 / 16)
        val r = c.dp(if (square) 16f else 8f).toFloat()
        h.card.background = GradientDrawable().apply { cornerRadius = r; setColor(0x22FFFFFF) }
        h.ring.cornerRadius = r
        h.ring.setStroke(c.dp(2f), 0)
        h.card.foreground = h.ring
        roundClip(h.img, r)
        h.itemView.setOnFocusChangeListener { v, f ->
            val s = if (f) 1.08f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            h.ring.setStroke(c.dp(2f), if (f) accent else 0)
        }
        return h
    }

    override fun onBindViewHolder(h: VH, i: Int) {
        val a = items[i]
        val c = h.itemView.context
        val e = Art.get(c, a.cn, !square)
        val kind = e?.kind ?: Art.ICON
        val full = kind == Art.BANNER || (kind == Art.CUSTOM && square)
        val side = h.card.layoutParams.height
        val pad = if (full) 0 else (side * (if (kind == Art.CUSTOM) 0.08f else 0.2f)).toInt()
        h.img.setPadding(pad, pad, pad, pad)
        h.img.scaleType = if (full) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        h.img.setImageDrawable(e?.d?.constantState?.newDrawable() ?: e?.d)
        h.label.text = a.label
        h.label.visibility = if (p.showNames) View.VISIBLE else View.GONE
        h.itemView.setOnClickListener { onClick(a) }
        h.itemView.setOnLongClickListener { onLong(a); true }
    }

    override fun getItemCount() = items.size
}
