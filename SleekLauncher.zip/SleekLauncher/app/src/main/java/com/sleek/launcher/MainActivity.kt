package com.sleek.launcher

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class AppItem(val label: String, val icon: Drawable, val intent: Intent)

class MainActivity : Activity() {

    private lateinit var list: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        list = findViewById(R.id.apps)
        list.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
    }

    override fun onResume() {
        super.onResume()
        list.adapter = AppAdapter(loadApps()) { startActivity(it.intent) }
        list.post { list.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus() }
    }

    private fun loadApps(): List<AppItem> {
        val pm = packageManager
        var query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        var found = pm.queryIntentActivities(query, 0)
        if (found.isEmpty()) {
            query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            found = pm.queryIntentActivities(query, 0)
        }
        val apps = found
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val ai = it.activityInfo
                AppItem(
                    it.loadLabel(pm).toString(),
                    it.loadIcon(pm),
                    Intent(Intent.ACTION_MAIN)
                        .setComponent(ComponentName(ai.packageName, ai.name))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
                )
            }
            .sortedBy { it.label.lowercase() }
        val settings = AppItem(
            getString(R.string.settings),
            getDrawable(android.R.drawable.ic_menu_preferences)!!,
            Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return apps + settings
    }

    // A launcher is the home screen: Back does nothing.
    @Deprecated("Home screen ignores Back")
    override fun onBackPressed() {}
}
