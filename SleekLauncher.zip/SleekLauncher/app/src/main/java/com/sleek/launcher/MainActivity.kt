package com.sleek.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        const val REQ_WP = 1
        const val REQ_LOGO = 2
        const val REQ_ICON = 3
        const val REQ_PERM = 77
        // tab / section indexes
        const val HOME = 0
        const val CONT = 1
        const val APPS = 2
        const val ESS = 3
        const val SET = 4
        private fun c(h: String) = Color.parseColor("#$h")
        val PRESETS = listOf(
            "Midnight" to intArrayOf(c("0B1226"), c("1B2A57"), c("05070F")),
            "Aurora" to intArrayOf(c("0F2027"), c("2C5364"), c("0A1418")),
            "Ember" to intArrayOf(c("1A0B0B"), c("6B2424"), c("0A0505")),
            "Violet" to intArrayOf(c("140B2B"), c("4A2A8A"), c("0A0516")),
            "Forest" to intArrayOf(c("07140D"), c("1E6B3F"), c("030A06")),
            "Slate" to intArrayOf(c("0F1115"), c("353B48"), c("08090B"))
        )
        val ACCENTS = listOf(
            "Blue" to c("4C8DFF"), "Teal" to c("2DD4BF"), "Amber" to c("FBBF24"),
            "Rose" to c("FB7185"), "Violet" to c("A78BFA"), "White" to c("FFFFFF")
        )
        val CLOCKS = listOf("Minimal", "Stacked", "Analog", "Flip", "Ring")
    }

    private var profile = 0
    private lateinit var p: Prefs
    private val io = Executors.newSingleThreadExecutor()
    private var apps: List<AppItem> = emptyList()
    private var section = HOME
    private var pendingIcon: String? = null
    private val refreshers = ArrayList<() -> Unit>()
    private lateinit var tabs: List<TextView>
    private lateinit var tabBg: List<GradientDrawable>

    private val wall by lazy { findViewById<ImageView>(R.id.wall) }
    private val dimView by lazy { findViewById<View>(R.id.dim) }
    private val logoBox by lazy { findViewById<FrameLayout>(R.id.logoBox) }
    private val logo by lazy { findViewById<ImageView>(R.id.logo) }
    private val topClock by lazy { findViewById<ClockView>(R.id.topClock) }
    private val content by lazy { findViewById<FrameLayout>(R.id.content) }
    private val home by lazy { findViewById<View>(R.id.home) }
    private val favTitle by lazy { findViewById<View>(R.id.favTitle) }
    private val sideList by lazy { findViewById<RecyclerView>(R.id.sideList) }
    private val favHint by lazy { findViewById<View>(R.id.favHint) }
    private val cont by lazy { findViewById<View>(R.id.cont) }
    private val watchHint by lazy { findViewById<TextView>(R.id.watchHint) }
    private val watchGrid by lazy { findViewById<RecyclerView>(R.id.watchGrid) }
    private val grid by lazy { findViewById<RecyclerView>(R.id.grid) }
    private val essScroll by lazy { findViewById<ScrollView>(R.id.essScroll) }
    private val rowFavs by lazy { findViewById<RecyclerView>(R.id.rowFavs) }
    private val essFavHint by lazy { findViewById<View>(R.id.essFavHint) }
    private val rowEss by lazy { findViewById<RecyclerView>(R.id.rowEss) }
    private val settingsScroll by lazy { findViewById<ScrollView>(R.id.settingsScroll) }
    private val settingsList by lazy { findViewById<LinearLayout>(R.id.settingsList) }

    // Make 1dp = same fraction of the screen on every TV, so fonts/cards look right at any dpi.
    override fun attachBaseContext(base: Context) {
        val dm = base.resources.displayMetrics
        val ui = Prefs(base, Profiles.active(base)).uiSize.coerceIn(0, 2)
        val dpWidth = intArrayOf(1100, 960, 840)[ui]
        val cfg = Configuration(base.resources.configuration)
        cfg.densityDpi = (maxOf(dm.widthPixels, dm.heightPixels) * 160f / dpWidth).toInt()
        cfg.fontScale = 1f
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        profile = Profiles.active(this)
        p = Prefs(this, profile)
        Art.iconDir = File(filesDir, "icons").apply { mkdirs() }
        setContentView(R.layout.activity_main)

        tabs = listOf(R.id.tab0, R.id.tab1, R.id.tab2, R.id.tab3, R.id.tab4).map { findViewById<TextView>(it) }
        tabBg = tabs.map { GradientDrawable().apply { cornerRadius = dp(16f).toFloat() } }
        tabs.forEachIndexed { i, t ->
            t.background = tabBg[i]
            t.setOnFocusChangeListener { _, f ->
                if (f) showSection(i)
                styleTabs()
            }
            t.setOnClickListener { showSection(i) }
        }

        // Logo = profile button (round square, never cropped by the bar)
        val ring = GradientDrawable().apply { cornerRadius = dp(11f).toFloat(); setColor(0x22FFFFFF); setStroke(dp(2f), 0) }
        logoBox.background = ring
        logoBox.setOnFocusChangeListener { v, f ->
            ring.setStroke(dp(2f), if (f) accent() else 0)
            val s = if (f) 1.1f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
        }
        logoBox.setOnClickListener { profileDialog() }
        roundClip(logo, dp(9f).toFloat())

        sideList.layoutManager = LinearLayoutManager(this)
        sideList.itemAnimator = null
        for (rv in listOf(rowFavs, rowEss)) {
            rv.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
            rv.itemAnimator = null
        }
        watchGrid.layoutManager = GridLayoutManager(this, 4)
        watchGrid.itemAnimator = null
        grid.layoutManager = GridLayoutManager(this, 6)
        grid.itemAnimator = null

        buildSettings()
        applyLogo(); applyWallpaper(); applyClock(); styleTabs()
        tabs[0].post { tabs[0].requestFocus() }
    }

    override fun onResume() {
        super.onResume()
        WatchStore.listener = { runOnUiThread { if (!isDestroyed) refreshWatch() } }
        loadApps()
        syncWatchNext()
        refreshers.forEach { it() }
    }

    override fun onPause() {
        WatchStore.listener = null
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true) tabs[0].requestFocus()
    }

    // ---------- files ----------
    private fun logoFile(i: Int = profile) = File(filesDir, "logo${Profiles.suffix(i)}.png")
    private fun wallFile() = File(filesDir, "wallpaper${Profiles.suffix(profile)}.jpg")
    private fun profileName(i: Int) = Prefs(this, i).name.ifBlank { "Profile ${i + 1}" }

    // ---------- apps ----------
    private fun loadApps() {
        io.execute {
            val pm = packageManager
            val seen = HashSet<String>()
            val out = ArrayList<AppItem>()
            fun scan(cat: String) {
                for (r in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                    val ai = r.activityInfo
                    if (ai.packageName == packageName || !seen.add(ai.packageName)) continue
                    out.add(AppItem(r.loadLabel(pm).toString(), ComponentName(ai.packageName, ai.name)))
                }
            }
            scan(Intent.CATEGORY_LEANBACK_LAUNCHER)
            if (p.showNonTv) scan(Intent.CATEGORY_LAUNCHER)
            val sorted = out.sortedBy { it.label.lowercase() }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                apps = sorted
                Art.clear()
                refreshLists()
                window.decorView.post { if (currentFocus == null) tabs[section].requestFocus() }
            }
        }
    }

    private fun favItems(): List<AppItem> { val f = p.favorites; return apps.filter { it.key in f } }

    private fun essentials(): List<AppItem> {
        fun sc(label: String, action: String, icon: Int) = AppItem(label, ComponentName("sleek.shortcut", action), icon)
        val l = arrayListOf(
            sc("Wi-Fi", Settings.ACTION_WIFI_SETTINGS, R.drawable.ic_wifi),
            sc("Bluetooth", Settings.ACTION_BLUETOOTH_SETTINGS, R.drawable.ic_bluetooth),
            sc("Display", Settings.ACTION_DISPLAY_SETTINGS, R.drawable.ic_display),
            sc("Sound", Settings.ACTION_SOUND_SETTINGS, R.drawable.ic_sound),
            sc("Storage", Settings.ACTION_INTERNAL_STORAGE_SETTINGS, R.drawable.ic_storage),
            sc("Date & time", Settings.ACTION_DATE_SETTINGS, R.drawable.ic_time),
            sc("Apps", Settings.ACTION_APPLICATION_SETTINGS, R.drawable.ic_apps),
            sc("Settings", Settings.ACTION_SETTINGS, R.drawable.ic_gear)
        )
        apps.firstOrNull { it.cn.packageName == "com.android.vending" }?.let { l.add(0, it) }
        return l
    }

    private fun adapter(list: List<AppItem>, mode: Int) = AppAdapter(list, p, accent(), mode, ::launch, ::menu)

    private fun refreshLists() {
        val favs = favItems()
        val side = favs.take(5)
        favTitle.visibility = vis(side.isNotEmpty())
        sideList.visibility = vis(side.isNotEmpty())
        favHint.visibility = vis(side.isEmpty())
        sideList.adapter = adapter(side, AppAdapter.M_SIDE)

        rowFavs.visibility = vis(favs.isNotEmpty())
        essFavHint.visibility = vis(favs.isEmpty())
        rowFavs.adapter = adapter(favs, AppAdapter.M_SQUARE)
        rowEss.adapter = adapter(essentials(), AppAdapter.M_SQUARE)

        if (section == APPS) bindGrid()
        refreshWatch()
    }

    private fun bindGrid() {
        val dm = resources.displayMetrics
        val span = maxOf(3, ((dm.widthPixels / dm.density - 76) / (AppAdapter.SQ[p.cardSize] + 12)).toInt())
        (grid.layoutManager as GridLayoutManager).spanCount = span
        grid.adapter = adapter(apps, AppAdapter.M_SQUARE)
    }

    // ---------- continue watching ----------
    private fun listenerOn() = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun syncWatchNext() {
        if (!WatchNext.granted(this)) return
        val ctx = applicationContext
        val pr = profile
        io.execute { WatchNext.refresh(ctx, pr) }
    }

    private fun refreshWatch() {
        var list = WatchStore.visible(this, profile)
        if (list.isEmpty()) {
            // Fallback so the tab is never empty: recently opened apps.
            val by = apps.associateBy { it.key }
            list = p.recent.mapNotNull { by[it] }.take(10)
                .map { WatchItem(it.key, it.cn.packageName, it.label, "", "", 0L, 0L, 0L, "", 2) }
        }
        val real = list.any { it.src != 2 }
        watchHint.text = if (listenerOn() || WatchNext.found > 0) {
            "Nothing playing yet. Start a movie or show in YouTube, Netflix or Nuvio and it will appear here."
        } else {
            "Showing recently opened apps. For real titles and progress, turn on Now playing access in Settings."
        }
        watchHint.visibility = vis(!real)
        val dm = resources.displayMetrics
        (watchGrid.layoutManager as GridLayoutManager).spanCount =
            maxOf(2, ((dm.widthPixels / dm.density - 76) / (WatchAdapter.W[p.cardSize] + 12)).toInt())
        watchGrid.adapter = WatchAdapter(list, p, accent(), ::openWatch, ::watchMenu)
    }

    private fun openApp(pkg: String) {
        val i = packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) { toast("App not installed"); return }
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { toast("Can't open it") }
    }

    private fun openWatch(w: WatchItem) {
        if (w.intent.isNotEmpty()) {
            try {
                val i = Intent.parseUri(w.intent, Intent.URI_INTENT_SCHEME)
                i.selector = null
                if (i.component != null && i.component?.packageName != w.pkg) i.component = null
                i.setPackage(w.pkg)
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                return
            } catch (e: Exception) { /* fall back to opening the app */ }
        }
        openApp(w.pkg)
    }

    private fun watchMenu(w: WatchItem) {
        if (w.src == 2) { openApp(w.pkg); return }
        AlertDialog.Builder(this).setTitle(w.title).setItems(arrayOf("Open app", "Remove from list")) { _, i ->
            if (i == 0) openApp(w.pkg) else WatchStore.remove(this, profile, w.key)
        }.show()
    }

    private fun openListenerSettings() {
        try {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } catch (e: Exception) {
            AlertDialog.Builder(this).setTitle("Turn on Now playing access")
                .setMessage("This TV has no screen for it. From an ADB shell (for example the ADB app on your TV) run:\n\ncmd notification allow_listener com.sleek.launcher/com.sleek.launcher.NowPlayingService")
                .setPositiveButton("OK", null).show()
        }
    }

    private fun askListings() {
        if (Build.VERSION.SDK_INT >= 23) requestPermissions(arrayOf(WatchNext.P1, WatchNext.P2), REQ_PERM)
        else toast("Not needed on this Android version")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        syncWatchNext()
        refreshers.forEach { it() }
    }

    // ---------- launching ----------
    private fun openSetting(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e2: Exception) { toast("Not available on this TV") }
        }
    }

    private fun launch(a: AppItem) {
        if (a.iconRes != 0) { openSetting(a.cn.className); return }
        p.pushRecent(a.key)
        try {
            startActivity(Intent(Intent.ACTION_MAIN).setComponent(a.cn)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        } catch (e: Exception) {
            toast("Can't open ${a.label}")
        }
    }

    private fun menu(a: AppItem) {
        if (a.iconRes != 0) return
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun opt(l: String, f: () -> Unit) { labels.add(l); acts.add(f) }
        val uri = Uri.parse("package:${a.cn.packageName}")
        opt(if (a.key in p.favorites) "Remove from favorites" else "Add to favorites") { p.toggleFavorite(a.key); refreshLists() }
        opt("Change icon") { pendingIcon = a.key; pick(REQ_ICON) }
        if (Art.customFile(a.key).exists()) opt("Reset icon") { Art.customFile(a.key).delete(); Art.clear(); refreshLists() }
        opt("App info") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)) }
        opt("Uninstall") { startActivity(Intent(Intent.ACTION_DELETE, uri)) }
        AlertDialog.Builder(this).setTitle(a.label).setItems(labels.toTypedArray()) { _, w ->
            try { acts[w]() } catch (e: Exception) { toast("Not available on this TV") }
        }.show()
    }

    // ---------- profiles ----------
    private fun profileDialog() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(20f), dp(12f), dp(20f), dp(8f))
        }
        val dlg = AlertDialog.Builder(this).setTitle("Who's using the TV?").setView(row).create()
        for (i in 0..1) {
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isFocusable = true
                isClickable = true
                setPadding(dp(18f), dp(12f), dp(18f), dp(12f))
            }
            val bg = GradientDrawable().apply { cornerRadius = dp(14f).toFloat(); setColor(0); setStroke(dp(2f), 0) }
            tile.background = bg
            tile.setOnFocusChangeListener { _, f -> bg.setStroke(dp(2f), if (f) accent() else 0) }
            val iv = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(64f), dp(64f))
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            roundClip(iv, dp(16f).toFloat())
            val lf = logoFile(i)
            val bmp = if (lf.exists()) Img.decode({ lf.inputStream() }, 128, 128) else null
            if (bmp != null) iv.setImageBitmap(bmp)
            else iv.setImageResource(if (i == 0) R.drawable.ic_logo else R.drawable.ic_logo2)
            val tv = TextView(this).apply {
                text = profileName(i) + (if (i == profile) " (current)" else "")
                textSize = 12f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(0, dp(8f), 0, 0)
            }
            tile.addView(iv)
            tile.addView(tv)
            tile.setOnClickListener {
                dlg.dismiss()
                if (i != profile) { Profiles.set(this, i); recreate() }
            }
            row.addView(tile)
        }
        dlg.show()
        row.getChildAt(profile).requestFocus()
    }

    // ---------- sections / tabs ----------
    private fun vis(b: Boolean) = if (b) View.VISIBLE else View.GONE

    private fun showSection(i: Int) {
        if (i == section) return
        section = i
        home.visibility = vis(i == HOME)
        cont.visibility = vis(i == CONT)
        grid.visibility = vis(i == APPS)
        essScroll.visibility = vis(i == ESS)
        settingsScroll.visibility = vis(i == SET)
        if (i == APPS) bindGrid()
        if (i == CONT) refreshWatch()
        styleTabs()
    }

    private fun accent() = ACCENTS[p.accent % ACCENTS.size].second

    private fun styleTabs() {
        tabs.forEachIndexed { i, t ->
            val sel = i == section
            tabBg[i].setColor(if (sel) Color.parseColor("#E3E3E3") else 0)
            tabBg[i].setStroke(dp(2f), if (t.isFocused) accent() else 0)
            t.setTextColor(if (sel) Color.parseColor("#111111") else Color.parseColor("#CCFFFFFF"))
        }
    }

    private fun inBar(v: View?) = v === logoBox || tabs.any { it === v }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val f = currentFocus
            if (f != null) {
                if (e.keyCode == KeyEvent.KEYCODE_DPAD_DOWN && inBar(f)) { content.requestFocus(); return true }
                if (e.keyCode == KeyEvent.KEYCODE_DPAD_UP && !inBar(f) && inBar(f.focusSearch(View.FOCUS_UP))) {
                    tabs[section].requestFocus(); return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    @Deprecated("Home screen: Back only returns to the top bar")
    override fun onBackPressed() {
        if (section != HOME || !inBar(currentFocus)) tabs[0].requestFocus()
    }

    // ---------- look ----------
    private fun applyClock() { topClock.configure(p.clockStyle, p.clock, accent()) }

    private fun applyDim() { dimView.setBackgroundColor((p.dim * 255 / 100) shl 24) }

    private fun applyWallpaper() {
        applyDim()
        val f = wallFile()
        if (p.wallpaper < 0 && f.exists()) {
            val dm = resources.displayMetrics
            val w = minOf(1920, dm.widthPixels)
            val h = minOf(1080, dm.heightPixels)
            io.execute {
                val bmp = Img.decode({ f.inputStream() }, w, h)
                runOnUiThread {
                    if (isDestroyed) return@runOnUiThread
                    if (bmp != null) wall.setImageDrawable(BitmapDrawable(resources, bmp)) else presetWall(0)
                }
            }
        } else presetWall(maxOf(p.wallpaper, 0))
    }

    private fun presetWall(i: Int) {
        wall.setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR, PRESETS[i % PRESETS.size].second))
    }

    private fun applyLogo() {
        val f = logoFile()
        if (f.exists()) {
            io.execute {
                val bmp = Img.decode({ f.inputStream() }, 128, 128)
                runOnUiThread { if (!isDestroyed && bmp != null) logo.setImageBitmap(bmp) }
            }
        } else {
            logo.setImageResource(if (profile == 0) R.drawable.ic_logo else R.drawable.ic_logo2)
        }
    }

    // ---------- settings ----------
    private fun addRow(title: String, value: () -> String, click: () -> Unit) {
        val v = layoutInflater.inflate(R.layout.item_setting, settingsList, false)
        val s = v.findViewById<TextView>(R.id.sValue)
        v.findViewById<TextView>(R.id.sTitle).text = title
        val bg = GradientDrawable().apply { cornerRadius = dp(8f).toFloat(); setColor(0x14FFFFFF) }
        v.background = bg
        v.setOnFocusChangeListener { _, f ->
            bg.setStroke(dp(2f), if (f) accent() else 0)
            bg.setColor(if (f) 0x26FFFFFF else 0x14FFFFFF)
        }
        val refresh = { s.text = value() }
        refreshers.add(refresh)
        refresh()
        v.setOnClickListener { click(); refreshers.forEach { it() } }
        settingsList.addView(v)
    }

    private fun buildSettings() {
        addRow("Switch profile", { profileName(profile) }) { profileDialog() }
        addRow("Profile name", { profileName(profile) }) { askName() }
        addRow("Custom logo", { if (logoFile().exists()) "Custom" else "Default" }) { pick(REQ_LOGO) }
        addRow("Reset logo", { "" }) { logoFile().delete(); applyLogo() }
        addRow("Custom wallpaper", { if (p.wallpaper < 0) "Photo in use" else "Choose photo" }) { pick(REQ_WP) }
        addRow("Built-in wallpapers", { if (p.wallpaper >= 0) PRESETS[p.wallpaper % PRESETS.size].first else "Tap to switch" }) {
            p.wallpaper = if (p.wallpaper < 0) 0 else (p.wallpaper + 1) % PRESETS.size
            applyWallpaper()
        }
        addRow("Wallpaper dimming", { "${p.dim}%" }) { p.dim = (p.dim + 20) % 100; applyDim() }
        addRow("Accent colour", { ACCENTS[p.accent % ACCENTS.size].first }) {
            p.accent = (p.accent + 1) % ACCENTS.size; styleTabs(); applyClock(); refreshLists()
        }
        addRow("Clock design", { CLOCKS[p.clockStyle % CLOCKS.size] }) { p.clockStyle = (p.clockStyle + 1) % CLOCKS.size; applyClock() }
        addRow("Clock format", { arrayOf("Auto", "12-hour", "24-hour")[p.clock] }) { p.clock = (p.clock + 1) % 3; applyClock() }
        addRow("UI size", { arrayOf("Small", "Default", "Large")[p.uiSize] }) { p.uiSize = (p.uiSize + 1) % 3; recreate() }
        addRow("Tile size", { arrayOf("Small", "Medium", "Large")[p.cardSize] }) { p.cardSize = (p.cardSize + 1) % 3; refreshLists() }
        addRow("App names", { if (p.showNames) "On" else "Off" }) { p.showNames = !p.showNames; refreshLists() }
        addRow("Show non-TV apps", { if (p.showNonTv) "On" else "Off" }) { p.showNonTv = !p.showNonTv; loadApps() }

        addRow("Now playing access", { if (listenerOn()) "On" else "Off" }) { openListenerSettings() }
        addRow("TV listings access", {
            if (!WatchNext.granted(this)) "Not granted" else when (WatchNext.found) { -2 -> "Blocked by Android"; -1 -> "Granted"; else -> "${WatchNext.found} found" }
        }) { askListings() }
        addRow("Show music in Continue watching", { if (p.showMusic) "On" else "Off" }) { p.showMusic = !p.showMusic }
        addRow("Clear Continue watching", { "" }) { WatchStore.clear(this, profile); WatchArt.clear() }

        addRow("Reset all app icons", { "" }) {
            Art.iconDir.listFiles()?.forEach { it.delete() }
            Art.clear()
            refreshLists()
        }
        addRow("Update source (GitHub)", { Profiles.repo(this).ifBlank { "Not set" } }) { askRepo() }
        addRow("Check for updates", { "" }) { checkUpdate() }
        addRow("System settings", { "" }) { openSetting(Settings.ACTION_SETTINGS) }
        addRow("About", { "Sleek Launcher 5.0 (build ${installedCode()})" }) { }
    }

    private fun askName() {
        val e = EditText(this).apply { setText(p.name); setSingleLine(); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle("Profile name").setView(e)
            .setPositiveButton("Save") { _, _ ->
                p.name = e.text.toString().trim()
                refreshers.forEach { it() }
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- self-update from your GitHub releases ----------
    @Suppress("DEPRECATION")
    private fun installedCode(): Int {
        val pi = packageManager.getPackageInfo(packageName, 0)
        return if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toInt() else pi.versionCode
    }

    private fun askRepo() {
        val e = EditText(this).apply { setText(Profiles.repo(this@MainActivity)); hint = "username/repo"; setSingleLine(); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle("GitHub repo for updates").setView(e)
            .setPositiveButton("Save") { _, _ ->
                Profiles.setRepo(this, e.text.toString().trim().removePrefix("https://github.com/").trim('/'))
                refreshers.forEach { it() }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun checkUpdate() {
        val slug = Profiles.repo(this)
        if (slug.isBlank()) { toast("Set Update source first (username/repo)"); return }
        toast("Checking for updates…")
        io.execute {
            try {
                val c = URL("https://api.github.com/repos/$slug/releases/latest").openConnection() as HttpURLConnection
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("User-Agent", "SleekLauncher")
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val js = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val tag = js.getString("tag_name")
                val n = tag.filter { it.isDigit() }.toIntOrNull() ?: 0
                var apk: String? = null
                val assets = js.getJSONArray("assets")
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.getString("name").endsWith(".apk")) { apk = a.getString("browser_download_url"); break }
                }
                val url = apk
                val newer = 100 + n > installedCode()
                runOnUiThread {
                    when {
                        url == null -> toast("No APK found in the latest release")
                        newer -> askInstall(tag, url)
                        else -> toast("You're up to date")
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Couldn't check for updates") }
            }
        }
    }

    private fun askInstall(tag: String, url: String) {
        AlertDialog.Builder(this).setTitle("Update available ($tag)").setMessage("Download and install it now?")
            .setPositiveButton("Install") { _, _ -> downloadAndInstall(url) }
            .setNegativeButton("Later", null).show()
    }

    private fun downloadAndInstall(url: String) {
        toast("Downloading update…")
        io.execute {
            try {
                val f = File(File(cacheDir, "update").apply { mkdirs() }, "update.apk")
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10000
                c.readTimeout = 20000
                c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                runOnUiThread { installApk(f) }
            } catch (e: Exception) {
                runOnUiThread { toast("Download failed") }
            }
        }
    }

    private fun installApk(f: File) {
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            toast("Allow Sleek Launcher to install apps, then check for updates again")
            try { startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))) } catch (e: Exception) { }
            return
        }
        try {
            val uri = FileProvider.getUriForFile(this, "com.sleek.launcher.fileprovider", f)
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            toast("Couldn't start the installer")
        }
    }

    // ---------- picking images ----------
    private fun pick(code: Int) {
        for (action in arrayOf(Intent.ACTION_OPEN_DOCUMENT, Intent.ACTION_GET_CONTENT)) {
            try {
                startActivityForResult(Intent(action).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), code)
                return
            } catch (e: ActivityNotFoundException) { /* try next */ }
        }
        Toast.makeText(this, "No file picker on this TV. Install a file manager, or use the built-in wallpapers.", Toast.LENGTH_LONG).show()
    }

    @Deprecated("Plain Activity result API")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        io.execute {
            try {
                when (req) {
                    REQ_WP -> { Img.saveWallpaper(this, uri, wallFile()); p.wallpaper = -1 }
                    REQ_LOGO -> Img.saveSquare(this, uri, logoFile())
                    REQ_ICON -> {
                        val k = pendingIcon ?: return@execute
                        Img.saveSquare(this, uri, Art.customFile(k))
                    }
                }
                runOnUiThread {
                    when (req) {
                        REQ_WP -> applyWallpaper()
                        REQ_LOGO -> applyLogo()
                        REQ_ICON -> { Art.clear(); refreshLists() }
                    }
                    refreshers.forEach { it() }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Couldn't load that image") }
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
