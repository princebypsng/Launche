package com.sleek.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        const val REQ_WP = 1
        const val REQ_LOGO = 2
        const val REQ_ICON = 3
        private fun c(h: String) = Color.parseColor("#$h")
        val PRESETS = listOf(
            "Midnight" to intArrayOf(c("0B1226"), c("1B2A57"), c("05070F")),
            "Aurora" to intArrayOf(c("0F2027"), c("2C5364"), c("0A1418")),
            "Ember" to intArrayOf(c("1A0B0B"), c("6B2424"), c("0A0505")),
            "Violet" to intArrayOf(c("140B2B"), c("4A2A8A"), c("0A0516")),
            "Forest" to intArrayOf(c("07140D"), c("1E6B3F"), c("030A06")),
            "Slate" to intArrayOf(c("0F1115"), c("353B48"), c("08090B"))
        )
        val ACCENTS = listOf(
            "Blue" to c("4C8DFF"), "Teal" to c("2DD4BF"), "Amber" to c("FBBF24"),
            "Rose" to c("FB7185"), "Violet" to c("A78BFA"), "White" to c("FFFFFF")
        )
        val CLOCKS = listOf("Minimal", "Stacked", "Analog", "Flip", "Ring")
    }

    private var profile = 0
    private lateinit var p: Prefs
    private val io = Executors.newSingleThreadExecutor()
    private var apps: List<AppItem> = emptyList()
    private var section = 0
    private var pendingIcon: String? = null
    private val refreshers = ArrayList<() -> Unit>()
    private lateinit var tabs: List<TextView>
    private lateinit var tabBg: List<GradientDrawable>

    private val wall by lazy { findViewById<ImageView>(R.id.wall) }
    private val dimView by lazy { findViewById<View>(R.id.dim) }
    private val logoBox by lazy { findViewById<FrameLayout>(R.id.logoBox) }
    private val logo by lazy { findViewById<ImageView>(R.id.logo) }
    private val clock by lazy { findViewById<TextClock>(R.id.clock) }
    private val content by lazy { findViewById<FrameLayout>(R.id.content) }
    private val home by lazy { findViewById<View>(R.id.home) }
    private val homeClock by lazy { findViewById<ClockView>(R.id.homeClock) }
    private val favTitle by lazy { findViewById<View>(R.id.favTitle) }
    private val rowFav by lazy { findViewById<RecyclerView>(R.id.rowFav) }
    private val favHint by lazy { findViewById<View>(R.id.favHint) }
    private val grid by lazy { findViewById<RecyclerView>(R.id.grid) }
    private val empty by lazy { findViewById<TextView>(R.id.empty) }
    private val settingsScroll by lazy { findViewById<ScrollView>(R.id.settingsScroll) }
    private val settingsList by lazy { findViewById<LinearLayout>(R.id.settingsList) }

    // Make 1dp = same fraction of the screen on every TV, so fonts/cards look right at any dpi.
    override fun attachBaseContext(base: Context) {
        val dm = base.resources.displayMetrics
        val ui = Prefs(base, Profiles.active(base)).uiSize.coerceIn(0, 2)
        val dpWidth = intArrayOf(1100, 960, 840)[ui]
        val cfg = Configuration(base.resources.configuration)
        cfg.densityDpi = (maxOf(dm.widthPixels, dm.heightPixels) * 160f / dpWidth).toInt()
        cfg.fontScale = 1f
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        profile = Profiles.active(this)
        p = Prefs(this, profile)
        Art.iconDir = File(filesDir, "icons").apply { mkdirs() }
        setContentView(R.layout.activity_main)

        tabs = listOf(R.id.tab0, R.id.tab1, R.id.tab2, R.id.tab3).map { findViewById<TextView>(it) }
        tabBg = tabs.map { GradientDrawable().apply { cornerRadius = dp(16f).toFloat() } }
        tabs.forEachIndexed { i, t ->
            t.background = tabBg[i]
            t.setOnFocusChangeListener { _, f ->
                if (f) showSection(i)
                styleTabs()
            }
            t.setOnClickListener { showSection(i) }
        }

        // Logo = profile button
        val ring = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0); setStroke(dp(2f), 0) }
        logoBox.background = ring
        logoBox.setOnFocusChangeListener { v, f ->
            ring.setStroke(dp(2f), if (f) accent() else 0)
            val s = if (f) 1.1f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
        }
        logoBox.setOnClickListener { profileDialog() }
        circleClip(logo)

        rowFav.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
        rowFav.itemAnimator = null
        grid.layoutManager = GridLayoutManager(this, 6)
        grid.itemAnimator = null

        buildSettings()
        applyLogo(); applyWallpaper(); applyClock(); styleTabs()
        tabs[0].post { tabs[0].requestFocus() }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true) tabs[0].requestFocus()
    }

    // ---------- files ----------
    private fun logoFile(i: Int = profile) = File(filesDir, "logo${Profiles.suffix(i)}.png")
    private fun wallFile() = File(filesDir, "wallpaper${Profiles.suffix(profile)}.jpg")
    private fun profileName(i: Int) = Prefs(this, i).name.ifBlank { "Profile ${i + 1}" }

    // ---------- apps ----------
    private fun loadApps() {
        io.execute {
            val pm = packageManager
            val seen = HashSet<String>()
            val out = ArrayList<AppItem>()
            fun scan(cat: String) {
                for (r in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                    val ai = r.activityInfo
                    if (ai.packageName == packageName || !seen.add(ai.packageName)) continue
                    out.add(AppItem(r.loadLabel(pm).toString(), ComponentName(ai.packageName, ai.name)))
                }
            }
            scan(Intent.CATEGORY_LEANBACK_LAUNCHER)
            if (p.showNonTv) scan(Intent.CATEGORY_LAUNCHER)
            val sorted = out.sortedBy { it.label.lowercase() }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                apps = sorted
                Art.clear()
                refreshLists()
                window.decorView.post { if (currentFocus == null) tabs[section].requestFocus() }
            }
        }
    }

    private fun favItems(): List<AppItem> { val f = p.favorites; return apps.filter { it.key in f } }

    private fun adapter(list: List<AppItem>, square: Boolean) = AppAdapter(list, p, accent(), square, ::launch, ::menu)

    private fun refreshLists() {
        val favs = favItems()
        favTitle.visibility = vis(favs.isNotEmpty())
        rowFav.visibility = vis(favs.isNotEmpty())
        favHint.visibility = vis(favs.isEmpty())
        rowFav.adapter = adapter(favs, true)
        if (section == 1 || section == 2) bindGrid()
    }

    private fun bindGrid() {
        val list = if (section == 2) favItems() else apps
        val dm = resources.displayMetrics
        val span = maxOf(3, ((dm.widthPixels / dm.density - 52) / (AppAdapter.CARD_W[p.cardSize] + 12)).toInt())
        (grid.layoutManager as GridLayoutManager).spanCount = span
        grid.adapter = adapter(list, false)
        empty.visibility = vis(section == 2 && list.isEmpty())
    }

    private fun launch(a: AppItem) {
        try {
            startActivity(Intent(Intent.ACTION_MAIN).setComponent(a.cn)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        } catch (e: Exception) {
            toast("Can't open ${a.label}")
        }
    }

    private fun menu(a: AppItem) {
        val labels = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun opt(l: String, f: () -> Unit) { labels.add(l); acts.add(f) }
        val uri = Uri.parse("package:${a.cn.packageName}")
        opt(if (a.key in p.favorites) "Remove from favorites" else "Add to favorites") { p.toggleFavorite(a.key); refreshLists() }
        opt("Change icon") { pendingIcon = a.key; pick(REQ_ICON) }
        if (Art.customFile(a.key).exists()) opt("Reset icon") { Art.customFile(a.key).delete(); Art.clear(); refreshLists() }
        opt("App info") { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri)) }
        opt("Uninstall") { startActivity(Intent(Intent.ACTION_DELETE, uri)) }
        AlertDialog.Builder(this).setTitle(a.label).setItems(labels.toTypedArray()) { _, w ->
            try { acts[w]() } catch (e: Exception) { toast("Not available on this TV") }
        }.show()
    }

    // ---------- profiles ----------
    private fun profileDialog() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(20f), dp(12f), dp(20f), dp(8f))
        }
        val dlg = AlertDialog.Builder(this).setTitle("Who's using the TV?").setView(row).create()
        for (i in 0..1) {
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isFocusable = true
                isClickable = true
                setPadding(dp(18f), dp(12f), dp(18f), dp(12f))
            }
            val bg = GradientDrawable().apply { cornerRadius = dp(12f).toFloat(); setColor(0); setStroke(dp(2f), 0) }
            tile.background = bg
            tile.setOnFocusChangeListener { _, f -> bg.setStroke(dp(2f), if (f) accent() else 0) }
            val iv = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(64f), dp(64f))
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            circleClip(iv)
            val lf = logoFile(i)
            val bmp = if (lf.exists()) Img.decode({ lf.inputStream() }, 128, 128) else null
            if (bmp != null) iv.setImageBitmap(bmp)
            else iv.setImageResource(if (i == 0) R.drawable.ic_logo else R.drawable.ic_logo2)
            val tv = TextView(this).apply {
                text = profileName(i) + (if (i == profile) " (current)" else "")
                textSize = 12f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(0, dp(8f), 0, 0)
            }
            tile.addView(iv)
            tile.addView(tv)
            tile.setOnClickListener {
                dlg.dismiss()
                if (i != profile) { Profiles.set(this, i); recreate() }
            }
            row.addView(tile)
        }
        dlg.show()
        row.getChildAt(profile).requestFocus()
    }

    // ---------- sections / tabs ----------
    private fun vis(b: Boolean) = if (b) View.VISIBLE else View.GONE

    private fun showSection(i: Int) {
        if (i == section) return
        section = i
        home.visibility = vis(i == 0)
        grid.visibility = vis(i == 1 || i == 2)
        settingsScroll.visibility = vis(i == 3)
        if (i == 1 || i == 2) bindGrid() else empty.visibility = View.GONE
        styleTabs()
    }

    private fun accent() = ACCENTS[p.accent % ACCENTS.size].second

    private fun styleTabs() {
        tabs.forEachIndexed { i, t ->
            val sel = i == section
            tabBg[i].setColor(if (sel) Color.parseColor("#E3E3E3") else 0)
            tabBg[i].setStroke(dp(2f), if (t.isFocused) accent() else 0)
            t.setTextColor(if (sel) Color.parseColor("#111111") else Color.parseColor("#CCFFFFFF"))
        }
    }

    private fun inBar(v: View?) = v === logoBox || tabs.any { it === v }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val f = currentFocus
            if (f != null) {
                if (e.keyCode == KeyEvent.KEYCODE_DPAD_DOWN && inBar(f)) { content.requestFocus(); return true }
                if (e.keyCode == KeyEvent.KEYCODE_DPAD_UP && !inBar(f) && inBar(f.focusSearch(View.FOCUS_UP))) {
                    tabs[section].requestFocus(); return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    @Deprecated("Home screen: Back only returns to the top bar")
    override fun onBackPressed() {
        if (section != 0 || !inBar(currentFocus)) tabs[0].requestFocus()
    }

    // ---------- look ----------
    private fun applyClock() {
        val f12 = "h:mm a"
        val f24 = "HH:mm"
        when (p.clock) {
            1 -> { clock.format12Hour = f12; clock.format24Hour = f12 }
            2 -> { clock.format12Hour = f24; clock.format24Hour = f24 }
            else -> { clock.format12Hour = f12; clock.format24Hour = f24 }
        }
        homeClock.configure(p.clockStyle, p.clock, accent())
    }

    private fun applyDim() { dimView.setBackgroundColor((p.dim * 255 / 100) shl 24) }

    private fun applyWallpaper() {
        applyDim()
        val f = wallFile()
        if (p.wallpaper < 0 && f.exists()) {
            val dm = resources.displayMetrics
            val w = minOf(1920, dm.widthPixels)
            val h = minOf(1080, dm.heightPixels)
            io.execute {
                val bmp = Img.decode({ f.inputStream() }, w, h)
                runOnUiThread {
                    if (isDestroyed) return@runOnUiThread
                    if (bmp != null) wall.setImageDrawable(BitmapDrawable(resources, bmp)) else presetWall(0)
                }
            }
        } else presetWall(maxOf(p.wallpaper, 0))
    }

    private fun presetWall(i: Int) {
        wall.setImageDrawable(GradientDrawable(GradientDrawable.Orientation.TL_BR, PRESETS[i % PRESETS.size].second))
    }

    private fun applyLogo() {
        val f = logoFile()
        if (f.exists()) {
            io.execute {
                val bmp = Img.decode({ f.inputStream() }, 128, 128)
                runOnUiThread { if (!isDestroyed && bmp != null) logo.setImageBitmap(bmp) }
            }
        } else {
            logo.setImageResource(if (profile == 0) R.drawable.ic_logo else R.drawable.ic_logo2)
        }
    }

    // ---------- settings ----------
    private fun addRow(title: String, value: () -> String, click: () -> Unit) {
        val v = layoutInflater.inflate(R.layout.item_setting, settingsList, false)
        val s = v.findViewById<TextView>(R.id.sValue)
        v.findViewById<TextView>(R.id.sTitle).text = title
        val bg = GradientDrawable().apply { cornerRadius = dp(8f).toFloat(); setColor(0x14FFFFFF) }
        v.background = bg
        v.setOnFocusChangeListener { _, f ->
            bg.setStroke(dp(2f), if (f) accent() else 0)
            bg.setColor(if (f) 0x26FFFFFF else 0x14FFFFFF)
        }
        val refresh = { s.text = value() }
        refreshers.add(refresh)
        refresh()
        v.setOnClickListener { click(); refreshers.forEach { it() } }
        settingsList.addView(v)
    }

    private fun buildSettings() {
        addRow("Switch profile", { profileName(profile) }) { profileDialog() }
        addRow("Profile name", { profileName(profile) }) { askName() }
        addRow("Custom logo", { if (logoFile().exists()) "Custom" else "Default" }) { pick(REQ_LOGO) }
        addRow("Reset logo", { "" }) { logoFile().delete(); applyLogo() }
        addRow("Custom wallpaper", { if (p.wallpaper < 0) "Photo in use" else "Choose photo" }) { pick(REQ_WP) }
        addRow("Built-in wallpapers", { if (p.wallpaper >= 0) PRESETS[p.wallpaper % PRESETS.size].first else "Tap to switch" }) {
            p.wallpaper = if (p.wallpaper < 0) 0 else (p.wallpaper + 1) % PRESETS.size
            applyWallpaper()
        }
        addRow("Wallpaper dimming", { "${p.dim}%" }) { p.dim = (p.dim + 20) % 100; applyDim() }
        addRow("Accent colour", { ACCENTS[p.accent % ACCENTS.size].first }) {
            p.accent = (p.accent + 1) % ACCENTS.size; styleTabs(); applyClock(); refreshLists()
        }
        addRow("Clock design", { CLOCKS[p.clockStyle % CLOCKS.size] }) { p.clockStyle = (p.clockStyle + 1) % CLOCKS.size; applyClock() }
        addRow("Clock format", { arrayOf("Auto", "12-hour", "24-hour")[p.clock] }) { p.clock = (p.clock + 1) % 3; applyClock() }
        addRow("UI size", { arrayOf("Small", "Default", "Large")[p.uiSize] }) { p.uiSize = (p.uiSize + 1) % 3; recreate() }
        addRow("Card size", { arrayOf("Small", "Medium", "Large")[p.cardSize] }) { p.cardSize = (p.cardSize + 1) % 3; refreshLists() }
        addRow("App names", { if (p.showNames) "On" else "Off" }) { p.showNames = !p.showNames; refreshLists() }
        addRow("Show non-TV apps", { if (p.showNonTv) "On" else "Off" }) { p.showNonTv = !p.showNonTv; loadApps() }
        addRow("Reset all app icons", { "" }) {
            Art.iconDir.listFiles()?.forEach { it.delete() }
            Art.clear()
            refreshLists()
        }
        addRow("System settings", { "" }) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e: Exception) { toast("Not available") }
        }
        addRow("About", { "Sleek Launcher 3.0" }) { }
    }

    private fun askName() {
        val e = EditText(this).apply { setText(p.name); setSingleLine(); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle("Profile name").setView(e)
            .setPositiveButton("Save") { _, _ ->
                p.name = e.text.toString().trim()
                refreshers.forEach { it() }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun pick(code: Int) {
        for (action in arrayOf(Intent.ACTION_OPEN_DOCUMENT, Intent.ACTION_GET_CONTENT)) {
            try {
                startActivityForResult(Intent(action).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), code)
                return
            } catch (e: ActivityNotFoundException) { /* try next */ }
        }
        Toast.makeText(this, "No file picker on this TV. Install a file manager, or use the built-in wallpapers.", Toast.LENGTH_LONG).show()
    }

    @Deprecated("Plain Activity result API")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        io.execute {
            try {
                when (req) {
                    REQ_WP -> { Img.saveWallpaper(this, uri, wallFile()); p.wallpaper = -1 }
                    REQ_LOGO -> Img.saveSquare(this, uri, logoFile())
                    REQ_ICON -> {
                        val k = pendingIcon ?: return@execute
                        Img.saveSquare(this, uri, Art.customFile(k))
                    }
                }
                runOnUiThread {
                    when (req) {
                        REQ_WP -> applyWallpaper()
                        REQ_LOGO -> applyLogo()
                        REQ_ICON -> { Art.clear(); refreshLists() }
                    }
                    refreshers.forEach { it() }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Couldn't load that image") }
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
