package com.sleek.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.view.View
import android.view.ViewOutlineProvider
import java.io.File
import java.io.InputStream

fun Context.dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun roundClip(v: View, radiusPx: Float) {
    v.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    v.clipToOutline = true
}

object Img {
    /** Decodes with the largest power-of-two sampling that still keeps the result >= maxW x maxH (low RAM). */
    fun decode(open: () -> InputStream?, maxW: Int, maxH: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / (s * 2) >= maxW && o.outHeight / (s * 2) >= maxH) s *= 2
        val d = BitmapFactory.Options().apply { inSampleSize = s }
        return open()?.use { BitmapFactory.decodeStream(it, null, d) }
    }

    fun saveWallpaper(ctx: Context, uri: Uri, out: File) {
        val b = decode({ ctx.contentResolver.openInputStream(uri) }, 1920, 1080) ?: error("decode failed")
        val s = if (b.width > 1920) Bitmap.createScaledBitmap(b, 1920, b.height * 1920 / b.width, true) else b
        out.outputStream().use { s.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    }

    /** Logos and app icons: near-square images fill the square; wide/tall images are fitted whole (nothing gets cut off). */
    fun saveSquare(ctx: Context, uri: Uri, out: File) {
        val b = decode({ ctx.contentResolver.openInputStream(uri) }, 256, 256) ?: error("decode failed")
        val dst = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
        val cv = Canvas(dst)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val ratio = b.width.toFloat() / b.height
        if (ratio in 0.8f..1.25f) {
            val side = minOf(b.width, b.height)
            val src = Rect((b.width - side) / 2, (b.height - side) / 2, (b.width + side) / 2, (b.height + side) / 2)
            cv.drawBitmap(b, src, Rect(0, 0, 256, 256), paint)
        } else {
            val sc = 232f / maxOf(b.width, b.height)
            val w = (b.width * sc).toInt()
            val h = (b.height * sc).toInt()
            val l = (256 - w) / 2
            val t = (256 - h) / 2
            cv.drawBitmap(b, null, Rect(l, t, l + w, t + h), paint)
        }
        out.outputStream().use { dst.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
