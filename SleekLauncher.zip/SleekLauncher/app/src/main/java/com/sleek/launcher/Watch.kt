package com.sleek.launcher

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.LruCache
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** src: 0 = live media session, 1 = Android TV "Watch Next", 2 = just a recently opened app (fallback). */
data class WatchItem(
    val key: String, val pkg: String, val title: String, val sub: String, val art: String,
    val pos: Long, val dur: Long, val ts: Long, val intent: String, val src: Int
)

object WatchStore {
    @Volatile var listener: (() -> Unit)? = null

    fun artDir(ctx: Context) = File(ctx.filesDir, "watchart").apply { mkdirs() }
    private fun file(ctx: Context, profile: Int) = File(ctx.filesDir, "watch${Profiles.suffix(profile)}.json")

    @Synchronized fun load(ctx: Context, profile: Int): MutableList<WatchItem> {
        val out = ArrayList<WatchItem>()
        try {
            val f = file(ctx, profile)
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(WatchItem(o.getString("key"), o.getString("pkg"), o.getString("title"), o.optString("sub"),
                        o.optString("art"), o.optLong("pos"), o.optLong("dur"), o.optLong("ts"), o.optString("intent"), o.optInt("src")))
                }
            }
        } catch (e: Exception) { /* corrupt file: start fresh */ }
        return out
    }

    @Synchronized private fun save(ctx: Context, profile: Int, list: List<WatchItem>) {
        val a = JSONArray()
        for (w in list) {
            a.put(JSONObject().put("key", w.key).put("pkg", w.pkg).put("title", w.title).put("sub", w.sub).put("art", w.art)
                .put("pos", w.pos).put("dur", w.dur).put("ts", w.ts).put("intent", w.intent).put("src", w.src))
        }
        file(ctx, profile).writeText(a.toString())
        listener?.invoke()
    }

    /** Newest first, one card per title (Watch Next wins over media-session entries because it has a deep link). */
    fun visible(ctx: Context, profile: Int): List<WatchItem> =
        load(ctx, profile).sortedWith(compareByDescending<WatchItem> { it.src }.thenByDescending { it.ts })
            .distinctBy { it.key }.sortedByDescending { it.ts }

    @Synchronized fun upsert(ctx: Context, profile: Int, item: WatchItem) {
        val l = load(ctx, profile)
        l.removeAll { it.key == item.key && it.src == item.src }
        l.add(0, item)
        save(ctx, profile, l.sortedByDescending { it.ts }.take(40))
    }

    @Synchronized fun remove(ctx: Context, profile: Int, key: String) {
        save(ctx, profile, load(ctx, profile).filter { it.key != key })
    }

    @Synchronized fun replaceSource(ctx: Context, profile: Int, src: Int, items: List<WatchItem>) {
        val l = load(ctx, profile).filter { it.src != src } + items
        save(ctx, profile, l.sortedByDescending { it.ts }.take(60))
    }

    fun clear(ctx: Context, profile: Int) = save(ctx, profile, emptyList())
}

/** Small capped bitmap cache + helper that stores downsized artwork as JPEG. */
object WatchArt {
    private val cache = object : LruCache<String, Bitmap>(6 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    fun clear() = cache.evictAll()

    fun get(ctx: Context, name: String): Bitmap? {
        if (name.isEmpty()) return null
        cache.get(name)?.let { return it }
        val b = BitmapFactory.decodeFile(File(WatchStore.artDir(ctx), name).path) ?: return null
        cache.put(name, b)
        return b
    }

    fun store(ctx: Context, src: Bitmap?, uri: String?, name: String): Boolean {
        val dst = File(WatchStore.artDir(ctx), name)
        if (dst.exists()) return true
        var b = src
        if (b == null && !uri.isNullOrEmpty()) b = load(ctx, uri)
        if (b == null) return false
        val w = 480
        val s = if (b.width > w) Bitmap.createScaledBitmap(b, w, b.height * w / b.width, true) else b
        dst.outputStream().use { s.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        return true
    }

    private fun load(ctx: Context, u: String): Bitmap? = try {
        val bytes: ByteArray? = if (u.startsWith("http")) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 8000
            if (c.contentLength > 6_000_000) null else c.inputStream.use { it.readBytes() }
        } else {
            ctx.contentResolver.openInputStream(Uri.parse(u))?.use { it.readBytes() }
        }
        if (bytes == null) null else Img.decode({ ByteArrayInputStream(bytes) }, 480, 270)
    } catch (e: Exception) {
        null
    }
}

/** Android TV "Watch Next" table. Android may only show rows to system launchers; we try and report honestly. */
object WatchNext {
    const val P1 = "android.permission.READ_TV_LISTINGS"
    const val P2 = "com.android.providers.tv.permission.READ_EPG_DATA"
    private val URI = Uri.parse("content://android.media.tv/watch_next_program")
    @Volatile var found = -1   // -1 not tried yet, -2 blocked by Android, >= 0 rows found

    fun granted(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 23 ||
            ctx.checkSelfPermission(P1) == PackageManager.PERMISSION_GRANTED ||
            ctx.checkSelfPermission(P2) == PackageManager.PERMISSION_GRANTED

    fun refresh(ctx: Context, profile: Int) {
        val items = ArrayList<WatchItem>()
        try {
            ctx.contentResolver.query(URI, null, null, null, null)?.use { c ->
                fun s(n: String): String? { val i = c.getColumnIndex(n); return if (i >= 0) c.getString(i) else null }
                fun l(n: String): Long { val i = c.getColumnIndex(n); return if (i >= 0) c.getLong(i) else 0L }
                while (c.moveToNext() && items.size < 30) {
                    val pkg = s("package_name") ?: continue
                    val title = s("title")?.trim().orEmpty()
                    if (pkg == ctx.packageName || title.isEmpty()) continue
                    val key = "$pkg|${title.lowercase()}"
                    val art = Integer.toHexString(key.hashCode()) + ".jpg"
                    val ok = WatchArt.store(ctx, null, s("thumbnail_uri") ?: s("poster_art_uri"), art)
                    val t = l("last_engagement_time_utc_millis")
                    val ts = if (t > 0) t else System.currentTimeMillis() - items.size * 1000L
                    items.add(WatchItem(key, pkg, title, s("short_description")?.trim().orEmpty(), if (ok) art else "",
                        l("last_playback_position_millis"), l("duration_millis"), ts, s("intent_uri").orEmpty(), 1))
                }
            }
            found = items.size
        } catch (e: Exception) {
            found = -2
        }
        if (found >= 0) WatchStore.replaceSource(ctx, profile, 1, items)
    }
}
