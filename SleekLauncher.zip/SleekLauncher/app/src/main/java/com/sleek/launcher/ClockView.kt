package com.sleek.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.format.DateFormat
import android.util.AttributeSet
import android.view.View
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/** One lightweight canvas view, five designs. Only ticks while visible (every second for Analog/Ring, every minute otherwise). */
class ClockView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    private var design = 0
    private var mode = 0
    private var accent = 0xFF4C8DFF.toInt()

    private val d = resources.displayMetrics.density
    private fun txt(face: Typeface, col: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = face; color = col }
    private val pLight = txt(Typeface.create("sans-serif-light", Typeface.NORMAL), 0xFFFFFFFF.toInt())
    private val pBold = txt(Typeface.create("sans-serif", Typeface.BOLD), 0xFFFFFFFF.toInt())
    private val pAccent = txt(Typeface.create("sans-serif", Typeface.BOLD), 0xFF4C8DFF.toInt())
    private val pDim = txt(Typeface.create("sans-serif-medium", Typeface.NORMAL), 0xB3FFFFFF.toInt())
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val rect = RectF()
    private val cal = Calendar.getInstance()
    private val dayFmt = SimpleDateFormat("EEEE", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("d MMMM", Locale.getDefault())

    private val ticker = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, delayMs()) }
    }

    fun configure(design: Int, mode: Int, accent: Int) {
        this.design = design
        this.mode = mode
        this.accent = accent
        schedule()
        invalidate()
    }

    private fun needsSeconds() = design == 2 || design == 4
    private fun delayMs(): Long {
        val n = System.currentTimeMillis()
        return if (needsSeconds()) 1005L - n % 1000 else 60050L - n % 60000
    }
    private fun schedule() { removeCallbacks(ticker); if (isShown) postDelayed(ticker, delayMs()) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); schedule() }
    override fun onDetachedFromWindow() { removeCallbacks(ticker); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (isShown) schedule() else removeCallbacks(ticker)
    }
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) schedule() else removeCallbacks(ticker)
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, ang: Double, len: Float, w: Float, col: Int) {
        line.color = col
        line.strokeWidth = w
        c.drawLine(cx, cy, cx + sin(ang).toFloat() * len, cy - cos(ang).toFloat() * len, line)
    }

    private fun sideDate(c: Canvas, x: Float, cy: Float, day: String, date: String) {
        pLight.textSize = height * 0.2f
        c.drawText(day, x, cy - 2 * d, pLight)
        pDim.textSize = height * 0.14f
        c.drawText(date, x, cy + height * 0.16f, pDim)
    }

    override fun onDraw(c: Canvas) {
        cal.timeInMillis = System.currentTimeMillis()
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val m = cal.get(Calendar.MINUTE)
        val s = cal.get(Calendar.SECOND)
        val is24 = when (mode) { 1 -> false; 2 -> true; else -> DateFormat.is24HourFormat(context) }
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        val hs = if (is24) "%02d".format(h24) else h12.toString()
        val ms = "%02d".format(m)
        val ap = if (is24) "" else if (h24 < 12) "AM" else "PM"
        val day = dayFmt.format(cal.time)
        val date = dateFmt.format(cal.time)
        val hh = height.toFloat()
        pAccent.color = accent

        when (design) {
            1 -> { // Stacked
                pBold.textSize = hh * 0.46f
                pAccent.textSize = hh * 0.46f
                c.drawText(hs, 0f, hh * 0.45f, pBold)
                c.drawText(ms, 0f, hh * 0.93f, pAccent)
                val x = maxOf(pBold.measureText(hs), pAccent.measureText(ms)) + 16 * d
                pDim.textSize = hh * 0.14f
                c.drawText(day, x, hh * 0.28f, pDim)
                c.drawText(date, x, hh * 0.45f, pDim)
                if (ap.isNotEmpty()) c.drawText(ap, x, hh * 0.62f, pDim)
            }
            2 -> { // Analog
                val r = hh * 0.44f
                val cx = r + 3 * d
                val cy = hh / 2f
                fill.color = 0x22FFFFFF
                c.drawCircle(cx, cy, r, fill)
                line.color = 0x55FFFFFF
                line.strokeWidth = 2 * d
                c.drawCircle(cx, cy, r, line)
                for (i in 0 until 12) {
                    val a = Math.toRadians(i * 30.0)
                    val r1 = r - 7 * d
                    val r2 = r1 - (if (i % 3 == 0) r * 0.14f else r * 0.07f)
                    line.color = 0xAAFFFFFF.toInt()
                    line.strokeWidth = (if (i % 3 == 0) 2.5f else 1.5f) * d
                    c.drawLine(cx + sin(a).toFloat() * r1, cy - cos(a).toFloat() * r1,
                        cx + sin(a).toFloat() * r2, cy - cos(a).toFloat() * r2, line)
                }
                hand(c, cx, cy, Math.toRadians(((h24 % 12) + m / 60.0) * 30.0), r * 0.5f, 4.5f * d, 0xFFFFFFFF.toInt())
                hand(c, cx, cy, Math.toRadians((m + s / 60.0) * 6.0), r * 0.76f, 3f * d, 0xFFFFFFFF.toInt())
                hand(c, cx, cy, Math.toRadians(s * 6.0), r * 0.84f, 1.5f * d, accent)
                fill.color = accent
                c.drawCircle(cx, cy, 4 * d, fill)
                sideDate(c, 2 * r + 28 * d, cy, day, date)
            }
            3 -> { // Flip cards
                val cw = hh * 0.68f
                val ch = hh * 0.7f
                val gap = 10 * d
                val rad = 12 * d
                for (k in 0..1) {
                    val x = k * (cw + gap)
                    val t = if (k == 0) hs else ms
                    rect.set(x, 0f, x + cw, ch)
                    fill.color = 0x33FFFFFF
                    c.drawRoundRect(rect, rad, rad, fill)
                    pBold.textSize = ch * 0.62f
                    c.drawText(t, x + (cw - pBold.measureText(t)) / 2f, ch / 2f + pBold.textSize * 0.36f, pBold)
                    line.color = 0x88000000.toInt()
                    line.strokeWidth = 2 * d
                    c.drawLine(x, ch / 2f, x + cw, ch / 2f, line)
                }
                pDim.textSize = hh * 0.14f
                c.drawText("$day, $date" + (if (ap.isEmpty()) "" else "  $ap"), 4 * d, ch + hh * 0.2f, pDim)
            }
            4 -> { // Ring (seconds arc)
                val r = hh * 0.42f
                val cx = r + 8 * d
                val cy = hh / 2f
                line.strokeWidth = hh * 0.05f
                line.color = 0x22FFFFFF
                c.drawCircle(cx, cy, r, line)
                line.color = accent
                rect.set(cx - r, cy - r, cx + r, cy + r)
                c.drawArc(rect, -90f, (s + 1) * 6f, false, line)
                val t = "$hs:$ms"
                pBold.textSize = r * 0.6f
                c.drawText(t, cx - pBold.measureText(t) / 2f, cy + pBold.textSize * 0.36f, pBold)
                if (ap.isNotEmpty()) {
                    pDim.textSize = r * 0.2f
                    c.drawText(ap, cx - pDim.measureText(ap) / 2f, cy + r * 0.55f, pDim)
                }
                sideDate(c, 2 * r + 32 * d, cy, day, date)
            }
            else -> { // Minimal
                pLight.textSize = hh * 0.55f
                val t = "$hs:$ms"
                c.drawText(t, 0f, hh * 0.58f, pLight)
                pDim.textSize = hh * 0.14f
                if (ap.isNotEmpty()) c.drawText(ap, pLight.measureText(t) + 8 * d, hh * 0.58f, pDim)
                c.drawText("$day, $date", 4 * d, hh * 0.8f, pDim)
            }
        }
    }
}
