package com.sleek.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.format.DateFormat
import android.util.AttributeSet
import android.view.View
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.sin

/** Small top-bar clock with five designs. Wraps to its content; ticks only while visible (1s for Analog/Ring, 1min otherwise). */
class ClockView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    private var design = 0
    private var mode = 0
    private var accent = 0xFF4C8DFF.toInt()

    private val d = resources.displayMetrics.density
    private fun txt(face: Typeface, col: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = face; color = col }
    private val pMed = txt(Typeface.create("sans-serif-medium", Typeface.NORMAL), 0xFFFFFFFF.toInt())
    private val pBold = txt(Typeface.create("sans-serif", Typeface.BOLD), 0xFFFFFFFF.toInt())
    private val pAccent = txt(Typeface.create("sans-serif", Typeface.BOLD), 0xFF4C8DFF.toInt())
    private val pDim = txt(Typeface.create("sans-serif-medium", Typeface.NORMAL), 0xB3FFFFFF.toInt())
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val rect = RectF()
    private val cal = Calendar.getInstance()

    private val ticker = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, delayMs()) }
    }

    fun configure(design: Int, mode: Int, accent: Int) {
        this.design = design
        this.mode = mode
        this.accent = accent
        requestLayout()
        schedule()
        invalidate()
    }

    private fun needsSeconds() = design == 2 || design == 4
    private fun delayMs(): Long {
        val n = System.currentTimeMillis()
        return if (needsSeconds()) 1005L - n % 1000 else 60050L - n % 60000
    }
    private fun schedule() { removeCallbacks(ticker); if (isShown) postDelayed(ticker, delayMs()) }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); schedule() }
    override fun onDetachedFromWindow() { removeCallbacks(ticker); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (isShown) schedule() else removeCallbacks(ticker)
    }
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) schedule() else removeCallbacks(ticker)
    }

    private fun is24() = when (mode) { 1 -> false; 2 -> true; else -> DateFormat.is24HourFormat(context) }

    /** Width of the AM/PM tag including its gap (0 in 24h mode). */
    private fun apW(hh: Float): Float {
        if (is24()) return 0f
        pDim.textSize = hh * 0.3f
        return 5 * d + pDim.measureText("PM")
    }

    private fun contentWidth(hh: Float): Float = when (design) {
        1 -> { pBold.textSize = hh * 0.46f; pBold.measureText("00") + apW(hh) }
        2 -> hh
        3 -> { val ch = hh * 0.92f; 2 * ch * 0.86f + 4 * d + apW(hh) }
        4 -> { pBold.textSize = hh * 0.5f; hh + 6 * d + pBold.measureText("00:00") + apW(hh) }
        else -> { pMed.textSize = hh * 0.62f; pMed.measureText("00:00") + apW(hh) }
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val h = MeasureSpec.getSize(hSpec)
        setMeasuredDimension(Math.ceil(contentWidth(h.toFloat()).toDouble()).toInt() + 2, h)
    }

    private fun hand(c: Canvas, cx: Float, cy: Float, ang: Double, len: Float, w: Float, col: Int) {
        line.color = col
        line.strokeWidth = w
        c.drawLine(cx, cy, cx + sin(ang).toFloat() * len, cy - cos(ang).toFloat() * len, line)
    }

    override fun onDraw(c: Canvas) {
        cal.timeInMillis = System.currentTimeMillis()
        val h24 = cal.get(Calendar.HOUR_OF_DAY)
        val m = cal.get(Calendar.MINUTE)
        val s = cal.get(Calendar.SECOND)
        val is24 = is24()
        val h12 = if (h24 % 12 == 0) 12 else h24 % 12
        val hs = if (is24) "%02d".format(h24) else h12.toString()
        val ms = "%02d".format(m)
        val ap = if (is24) "" else if (h24 < 12) "AM" else "PM"
        val hh = height.toFloat()
        val cy = hh / 2f
        pAccent.color = accent

        when (design) {
            1 -> { // Stacked
                pBold.textSize = hh * 0.46f
                pAccent.textSize = hh * 0.46f
                c.drawText(hs, 0f, hh * 0.47f, pBold)
                c.drawText(ms, 0f, hh * 0.96f, pAccent)
                if (ap.isNotEmpty()) {
                    pDim.textSize = hh * 0.3f
                    c.drawText(ap, pBold.measureText("00") + 5 * d, cy + pDim.textSize * 0.36f, pDim)
                }
            }
            2 -> { // Analog
                val r = hh * 0.46f
                fill.color = 0x22FFFFFF
                c.drawCircle(cy, cy, r, fill)
                line.color = 0x77FFFFFF
                line.strokeWidth = 1.2f * d
                c.drawCircle(cy, cy, r, line)
                for (i in 0 until 4) {
                    val a = Math.toRadians(i * 90.0)
                    val r1 = r - 2.5f * d
                    val r2 = r1 - r * 0.16f
                    line.color = 0xBBFFFFFF.toInt()
                    line.strokeWidth = 1.2f * d
                    c.drawLine(cy + sin(a).toFloat() * r1, cy - cos(a).toFloat() * r1,
                        cy + sin(a).toFloat() * r2, cy - cos(a).toFloat() * r2, line)
                }
                hand(c, cy, cy, Math.toRadians(((h24 % 12) + m / 60.0) * 30.0), r * 0.5f, 2f * d, 0xFFFFFFFF.toInt())
                hand(c, cy, cy, Math.toRadians((m + s / 60.0) * 6.0), r * 0.78f, 1.5f * d, 0xFFFFFFFF.toInt())
                hand(c, cy, cy, Math.toRadians(s * 6.0), r * 0.86f, 1f * d, accent)
                fill.color = accent
                c.drawCircle(cy, cy, 1.8f * d, fill)
            }
            3 -> { // Flip
                val ch = hh * 0.92f
                val cw = ch * 0.86f
                val top = (hh - ch) / 2f
                val rad = 5 * d
                for (k in 0..1) {
                    val x = k * (cw + 4 * d)
                    rect.set(x, top, x + cw, top + ch)
                    fill.color = 0x33FFFFFF
                    c.drawRoundRect(rect, rad, rad, fill)
                    val t = if (k == 0) hs else ms
                    pBold.textSize = ch * 0.58f
                    c.drawText(t, x + (cw - pBold.measureText(t)) / 2f, cy + pBold.textSize * 0.36f, pBold)
                    line.color = 0x88000000.toInt()
                    line.strokeWidth = 1f * d
                    c.drawLine(x, cy, x + cw, cy, line)
                }
                if (ap.isNotEmpty()) {
                    pDim.textSize = hh * 0.3f
                    c.drawText(ap, 2 * cw + 9 * d, cy + pDim.textSize * 0.36f, pDim)
                }
            }
            4 -> { // Ring with seconds arc
                val r = hh * 0.4f
                line.strokeWidth = hh * 0.11f
                line.color = 0x22FFFFFF
                c.drawCircle(cy, cy, r, line)
                line.color = accent
                rect.set(cy - r, cy - r, cy + r, cy + r)
                c.drawArc(rect, -90f, (s + 1) * 6f, false, line)
                pBold.textSize = hh * 0.5f
                val t = "$hs:$ms"
                val x0 = hh + 6 * d
                c.drawText(t, x0, cy + pBold.textSize * 0.36f, pBold)
                if (ap.isNotEmpty()) {
                    pDim.textSize = hh * 0.3f
                    c.drawText(ap, x0 + pBold.measureText(t) + 5 * d, cy + pDim.textSize * 0.36f, pDim)
                }
            }
            else -> { // Minimal
                pMed.textSize = hh * 0.62f
                val t = "$hs:$ms"
                c.drawText(t, 0f, cy + pMed.textSize * 0.36f, pMed)
                if (ap.isNotEmpty()) {
                    pDim.textSize = hh * 0.3f
                    c.drawText(ap, pMed.measureText(t) + 5 * d, cy + pDim.textSize * 0.36f, pDim)
                }
            }
        }
    }
}
