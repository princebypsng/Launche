package com.sleek.launcher

import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.util.LruCache
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class AppItem(val label: String, val cn: ComponentName) {
    val key: String get() = cn.flattenToString()
}

/** Small LRU cache: icons/banners are loaded lazily, only for what is on screen. */
object Art {
    class Entry(val d: Drawable, val banner: Boolean)
    private val cache = LruCache<String, Entry>(40)
    fun clear() = cache.evictAll()
    fun get(pm: PackageManager, cn: ComponentName): Entry? {
        val k = cn.flattenToString()
        cache.get(k)?.let { return it }
        return try {
            val b = pm.getActivityBanner(cn)
            val e = if (b != null) Entry(b, true) else Entry(pm.getActivityIcon(cn), false)
            cache.put(k, e)
            e
        } catch (e: Exception) {
            null
        }
    }
}

class AppAdapter(
    private val items: List<AppItem>,
    private val p: Prefs,
    private val accent: Int,
    private val onClick: (AppItem) -> Unit,
    private val onLong: (AppItem) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    companion object { val CARD_W = intArrayOf(104, 128, 152) }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: FrameLayout = v.findViewById(R.id.card)
        val img: ImageView = v.findViewById(R.id.img)
        val label: TextView = v.findViewById(R.id.label)
        val ring = GradientDrawable()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val c = parent.context
        val h = VH(LayoutInflater.from(c).inflate(R.layout.item_app, parent, false))
        val w = c.dp(CARD_W[p.cardSize].toFloat())
        h.card.layoutParams = LinearLayout.LayoutParams(w, w * 9 / 16)
        val r = c.dp(8f).toFloat()
        h.card.background = GradientDrawable().apply { cornerRadius = r; setColor(0x22FFFFFF) }
        h.ring.cornerRadius = r
        h.ring.setStroke(c.dp(2f), 0)
        h.card.foreground = h.ring
        roundClip(h.img, r)
        h.itemView.setOnFocusChangeListener { v, f ->
            val s = if (f) 1.08f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            h.ring.setStroke(c.dp(2f), if (f) accent else 0)
        }
        return h
    }

    override fun onBindViewHolder(h: VH, i: Int) {
        val a = items[i]
        val c = h.itemView.context
        val e = Art.get(c.packageManager, a.cn)
        val banner = e?.banner == true
        val pad = if (banner) 0 else c.dp(CARD_W[p.cardSize] * 9f / 16 * 0.18f)
        h.img.setPadding(pad, pad, pad, pad)
        h.img.scaleType = if (banner) ImageView.ScaleType.CENTER_CROP else ImageView.ScaleType.FIT_CENTER
        h.img.setImageDrawable(e?.d?.constantState?.newDrawable() ?: e?.d)
        h.label.text = a.label
        h.label.visibility = if (p.showNames) View.VISIBLE else View.GONE
        h.itemView.setOnClickListener { onClick(a) }
        h.itemView.setOnLongClickListener { onLong(a); true }
    }

    override fun getItemCount() = items.size
}
