package com.sleek.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        const val REQ_WP = 1
        const val REQ_LOGO = 2
        private fun c(h: String) = Color.parseColor("#$h")
        val PRESETS = listOf(
            "Midnight" to intArrayOf(c("0B1226"), c("1B2A57"), c("05070F")),
            "Aurora" to intArrayOf(c("0F2027"), c("2C5364"), c("0A1418")),
            "Ember" to intArrayOf(c("1A0B0B"), c("6B2424"), c("0A0505")),
            "Violet" to intArrayOf(c("140B2B"), c("4A2A8A"), c("0A0516")),
            "Forest" to intArrayOf(c("07140D"), c("1E6B3F"), c("030A06")),
            "Slate" to intArrayOf(c("0F1115"), c("353B48"), c("08090B"))
        )
        val ACCENTS = listOf(
            "Blue" to c("4C8DFF"), "Teal" to c("2DD4BF"), "Amber" to c("FBBF24"),
            "Rose" to c("FB7185"), "Violet" to c("A78BFA"), "White" to c("FFFFFF")
        )
    }

    private lateinit var p: Prefs
    private val io = Executors.newSingleThreadExecutor()
    private var apps: List<AppItem> = emptyList()
    private var section = 0
    private val refreshers = ArrayList<() -> Unit>()
    private lateinit var tabs: List<TextView>
    private lateinit var tabBg: List<GradientDrawable>

    private val wall by lazy { findViewById<ImageView>(R.id.wall) }
    private val dimView by lazy { findViewById<View>(R.id.dim) }
    private val logo by lazy { findViewById<ImageView>(R.id.logo) }
    private val clock by lazy { findViewById<TextClock>(R.id.clock) }
    private val content by lazy { findViewById<FrameLayout>(R.id.content) }
    private val homeScroll by lazy { findViewById<ScrollView>(R.id.homeScroll) }
    private val hero by lazy { findViewById<FrameLayout>(R.id.hero) }
    private val heroImg by lazy { findViewById<ImageView>(R.id.heroImg) }
    private val heroTitle by lazy { findViewById<TextView>(R.id.heroTitle) }
    private val heroSub by lazy { findViewById<TextView>(R.id.heroSub) }
    private val recentTitle by lazy { findViewById<View>(R.id.recentTitle) }
    private val favTitle by lazy { findViewById<View>(R.id.favTitle) }
    private val rowRecent by lazy { findViewById<RecyclerView>(R.id.rowRecent) }
    private val rowFav by lazy { findViewById<RecyclerView>(R.id.rowFav) }
    private val rowAll by lazy { findViewById<RecyclerView>(R.id.rowAll) }
    private val grid by lazy { findViewById<RecyclerView>(R.id.grid) }
    private val empty by lazy { findViewById<TextView>(R.id.empty) }
    private val settingsScroll by lazy { findViewById<ScrollView>(R.id.settingsScroll) }
    private val settingsList by lazy { findViewById<LinearLayout>(R.id.settingsList) }

    // Make 1dp = same fraction of the screen on every TV, so fonts/cards look right at any dpi.
    override fun attachBaseContext(base: Context) {
        val dm = base.resources.displayMetrics
        val dpWidth = intArrayOf(1100, 960, 840)[Prefs(base).uiSize.coerceIn(0, 2)]
        val cfg = Configuration(base.resources.configuration)
        cfg.densityDpi = (maxOf(dm.widthPixels, dm.heightPixels) * 160f / dpWidth).toInt()
        cfg.fontScale = 1f
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs(this)
        setContentView(R.layout.activity_main)

        tabs = listOf(R.id.tab0, R.id.tab1, R.id.tab2, R.id.tab3).map { findViewById<TextView>(it) }
        tabBg = tabs.map { GradientDrawable().apply { cornerRadius = dp(16f).toFloat() } }
        tabs.forEachIndexed { i, t ->
            t.background = tabBg[i]
            t.setOnFocusChangeListener { _, f ->
                if (f) showSection(i)
                styleTabs()
            }
            t.setOnClickListener { showSection(i) }
        }

        roundClip(hero, dp(12f).toFloat())
        circleClip(logo)
        for (rv in listOf(rowRecent, rowFav, rowAll)) {
            rv.layoutManager = LinearLayoutManager(this, RecyclerView.HORIZONTAL, false)
            rv.itemAnimator = null
        }
        grid.layoutManager = GridLayoutManager(this, 6)
        grid.itemAnimator = null

        buildSettings()
        applyLogo(); applyWallpaper(); applyClock(); updateHero(); styleTabs()
        tabs[0].post { tabs[0].requestFocus() }
    }

    override fun onResume() {
        super.onResume()
        updateHero()
        loadApps()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.hasCategory(Intent.CATEGORY_HOME) == true) {
            tabs[0].requestFocus()
            homeScroll.scrollTo(0, 0)
        }
    }

    // ---------- apps ----------
    private fun loadApps() {
        io.execute {
            val pm = packageManager
            val seen = HashSet<String>()
            val out = ArrayList<AppItem>()
            fun scan(cat: String) {
                for (r in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                    val ai = r.activityInfo
                    if (ai.packageName == packageName || !seen.add(ai.packageName)) continue
                    out.add(AppItem(r.loadLabel(pm).toString(), ComponentName(ai.packageName, ai.name)))
                }
            }
            scan(Intent.CATEGORY_LEANBACK_LAUNCHER)
            if (p.showNonTv) scan(Intent.CATEGORY_LAUNCHER)
            val sorted = out.sortedBy { it.label.lowercase() }
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                apps = sorted
                Art.clear()
                refreshLists()
                updateHero()
                window.decorView.post { if (currentFocus == null) tabs[section].requestFocus() }
            }
        }
    }

    private fun favItems(): List<AppItem> { val f = p.favorites; return apps.filter { it.key in f } }

    private fun adapter(list: List<AppItem>) = AppAdapter(list, p, accent(), ::launch, ::menu)

    private fun setRow(title: View?, rv: RecyclerView, list: List<AppItem>) {
        val v = if (list.isNotEmpty()) View.VISIBLE else View.GONE
        title?.visibility = v
        rv.visibility = v
        rv.adapter = adapter(list)
    }

    private fun refreshLists() {
        val by = apps.associateBy { it.key }
        setRow(recentTitle, rowRecent, p.recent.mapNotNull { by[it] }.take(12))
        setRow(favTitle, rowFav, favItems())
        setRow(null, rowAll, apps)
        if (section == 1 || section == 2) bindGrid()
    }

    private fun bindGrid() {
        val list = if (section == 2) favItems() else apps
        val dm = resources.displayMetrics
        val span = maxOf(3, ((dm.widthPixels / dm.density - 52) / (AppAdapter.CARD_W[p.cardSize] + 12)).toInt())
        (grid.layoutManager as GridLayoutManager).spanCount = span
        grid.adapter = adapter(list)
        empty.visibility = if (section == 2 && list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun launch(a: AppItem) {
        p.pushRecent(a.key)
        try {
            startActivity(Intent(Intent.ACTION_MAIN).setComponent(a.cn)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED))
        } catch (e: Exception) {
            toast("Can't open ${a.label}")
        }
    }

    private fun menu(a: AppItem) {
        val fav = a.key in p.favorites
        val opts = arrayOf(if (fav) "Remove from favorites" else "Add to favorites", "App info", "Uninstall")
        AlertDialog.Builder(this).setTitle(a.label).setItems(opts) { _, w ->
            val uri = Uri.parse("package:${a.cn.packageName}")
            try {
                when (w) {
                    0 -> { p.toggleFavorite(a.key); refreshLists() }
                    1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                    2 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
                }
            } catch (e: Exception) { toast("Not available on this TV") }
        }.show()
    }

    // ---------- sections / tabs ----------
    private fun vis(b: Boolean) = if (b) View.VISIBLE else View.GONE

    private fun showSection(i: Int) {
        if (i == section) return
        section = i
        homeScroll.visibility = vis(i == 0)
        grid.visibility = vis(i == 1 || i == 2)
        settingsScroll.visibility = vis(i == 3)
        if (i == 1 || i == 2) bindGrid() else empty.visibility = View.GONE
        styleTabs()
    }

    private fun accent() = ACCENTS[p.accent % ACCENTS.size].second

    private fun styleTabs() {
        tabs.forEachIndexed { i, t ->
            val sel = i == section
            tabBg[i].setColor(if (sel) Color.parseColor("#E3E3E3") else 0)
            tabBg[i].setStroke(dp(2f), if (t.isFocused) accent() else 0)
            t.setTextColor(if (sel) Color.parseColor("#111111") else Color.parseColor("#CCFFFFFF"))
        }
    }

    private fun inTabs(v: View?) = tabs.any { it === v }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val f = currentFocus
            if (f != null) {
                if (e.keyCode == KeyEvent.KEYCODE_DPAD_DOWN && inTabs(f)) { content.requestFocus(); return true }
                if (e.keyCode == KeyEvent.KEYCODE_DPAD_UP && !inTabs(f) && inTabs(f.focusSearch(View.FOCUS_UP))) {
                    tabs[section].requestFocus(); return true
                }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    @Deprecated("Home screen: Back only returns to the top")
    override fun onBackPressed() {
        if (section != 0 || !inTabs(currentFocus)) {
            tabs[0].requestFocus()
            homeScroll.scrollTo(0, 0)
        }
    }

    // ---------- look ----------
    private fun updateHero() {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val g = when {
            h < 5 -> "Good night"; h < 12 -> "Good morning"; h < 17 -> "Good afternoon"; h < 21 -> "Good evening"; else -> "Good night"
        }
        heroTitle.text = if (p.name.isBlank()) g else "$g, ${p.name}"
        heroSub.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()) + "   ·   ${apps.size} apps"
    }

    private fun applyClock() {
        val f12 = "h:mm a"
        val f24 = "HH:mm"
        when (p.clock) {
            1 -> { clock.format12Hour = f12; clock.format24Hour = f12 }
            2 -> { clock.format12Hour = f24; clock.format24Hour = f24 }
            else -> { clock.format12Hour = f12; clock.format24Hour = f24 }
        }
    }

    private fun applyDim() { dimView.setBackgroundColor((p.dim * 255 / 100) shl 24) }

    private fun setWall(make: () -> Drawable) {
        wall.setImageDrawable(make())
        heroImg.setImageDrawable(make())   // two drawables, one shared bitmap: no extra RAM
    }

    private fun applyWallpaper() {
        applyDim()
        val f = File(filesDir, "wallpaper.jpg")
        if (p.wallpaper < 0 && f.exists()) {
            val dm = resources.displayMetrics
            val w = minOf(1920, dm.widthPixels)
            val h = minOf(1080, dm.heightPixels)
            io.execute {
                val bmp = Img.decode({ f.inputStream() }, w, h)
                runOnUiThread {
                    if (isDestroyed) return@runOnUiThread
                    if (bmp != null) setWall { BitmapDrawable(resources, bmp) } else presetWall(0)
                }
            }
        } else presetWall(maxOf(p.wallpaper, 0))
    }

    private fun presetWall(i: Int) {
        val cols = PRESETS[i % PRESETS.size].second
        setWall { GradientDrawable(GradientDrawable.Orientation.TL_BR, cols) }
    }

    private fun applyLogo() {
        val f = File(filesDir, "logo.png")
        if (f.exists()) {
            io.execute {
                val bmp = Img.decode({ f.inputStream() }, 128, 128)
                runOnUiThread { if (!isDestroyed && bmp != null) logo.setImageBitmap(bmp) }
            }
        } else logo.setImageResource(R.drawable.ic_logo)
    }

    // ---------- settings ----------
    private fun addRow(title: String, value: () -> String, click: () -> Unit) {
        val v = layoutInflater.inflate(R.layout.item_setting, settingsList, false)
        val s = v.findViewById<TextView>(R.id.sValue)
        v.findViewById<TextView>(R.id.sTitle).text = title
        val bg = GradientDrawable().apply { cornerRadius = dp(8f).toFloat(); setColor(0x14FFFFFF) }
        v.background = bg
        v.setOnFocusChangeListener { _, f ->
            bg.setStroke(dp(2f), if (f) accent() else 0)
            bg.setColor(if (f) 0x26FFFFFF else 0x14FFFFFF)
        }
        val refresh = { s.text = value() }
        refreshers.add(refresh)
        refresh()
        v.setOnClickListener { click(); refreshers.forEach { it() } }
        settingsList.addView(v)
    }

    private fun buildSettings() {
        val logoFile = File(filesDir, "logo.png")
        addRow("Custom logo", { if (logoFile.exists()) "Custom" else "Default" }) { pick(REQ_LOGO) }
        addRow("Reset logo", { "" }) { logoFile.delete(); applyLogo() }
        addRow("Custom wallpaper", { if (p.wallpaper < 0) "Photo in use" else "Choose photo" }) { pick(REQ_WP) }
        addRow("Built-in wallpapers", { if (p.wallpaper >= 0) PRESETS[p.wallpaper % PRESETS.size].first else "Tap to switch" }) {
            p.wallpaper = if (p.wallpaper < 0) 0 else (p.wallpaper + 1) % PRESETS.size
            applyWallpaper()
        }
        addRow("Wallpaper dimming", { "${p.dim}%" }) { p.dim = (p.dim + 20) % 100; applyDim() }
        addRow("Accent colour", { ACCENTS[p.accent % ACCENTS.size].first }) {
            p.accent = (p.accent + 1) % ACCENTS.size; styleTabs(); refreshLists()
        }
        addRow("Clock format", { arrayOf("Auto", "12-hour", "24-hour")[p.clock] }) { p.clock = (p.clock + 1) % 3; applyClock() }
        addRow("UI size", { arrayOf("Small", "Default", "Large")[p.uiSize] }) { p.uiSize = (p.uiSize + 1) % 3; recreate() }
        addRow("Card size", { arrayOf("Small", "Medium", "Large")[p.cardSize] }) { p.cardSize = (p.cardSize + 1) % 3; refreshLists() }
        addRow("App names", { if (p.showNames) "On" else "Off" }) { p.showNames = !p.showNames; refreshLists() }
        addRow("Show non-TV apps", { if (p.showNonTv) "On" else "Off" }) { p.showNonTv = !p.showNonTv; loadApps() }
        addRow("Display name", { p.name.ifBlank { "Not set" } }) { askName() }
        addRow("System settings", { "" }) { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e: Exception) { toast("Not available") } }
        addRow("About", { "Sleek Launcher 2.0" }) { }
    }

    private fun askName() {
        val e = EditText(this).apply { setText(p.name); setSingleLine(); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle("Display name").setView(e)
            .setPositiveButton("Save") { _, _ ->
                p.name = e.text.toString().trim()
                updateHero()
                refreshers.forEach { it() }
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun pick(code: Int) {
        for (action in arrayOf(Intent.ACTION_OPEN_DOCUMENT, Intent.ACTION_GET_CONTENT)) {
            try {
                startActivityForResult(Intent(action).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), code)
                return
            } catch (e: ActivityNotFoundException) { /* try next */ }
        }
        Toast.makeText(this, "No file picker on this TV. Use Built-in wallpapers, or install a file manager.", Toast.LENGTH_LONG).show()
    }

    @Deprecated("Plain Activity result API")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        io.execute {
            try {
                if (req == REQ_WP) { Img.saveWallpaper(this, uri, File(filesDir, "wallpaper.jpg")); p.wallpaper = -1 }
                else Img.saveLogo(this, uri, File(filesDir, "logo.png"))
                runOnUiThread {
                    if (req == REQ_WP) applyWallpaper() else applyLogo()
                    refreshers.forEach { it() }
                }
            } catch (e: Exception) {
                runOnUiThread { toast("Couldn't load that image") }
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
