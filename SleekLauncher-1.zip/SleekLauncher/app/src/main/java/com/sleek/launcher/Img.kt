package com.sleek.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.net.Uri
import android.view.View
import android.view.ViewOutlineProvider
import java.io.File
import java.io.InputStream

fun Context.dp(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun roundClip(v: View, radiusPx: Float) {
    v.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radiusPx)
        }
    }
    v.clipToOutline = true
}

fun circleClip(v: View) {
    v.outlineProvider = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setOval(0, 0, view.width, view.height)
        }
    }
    v.clipToOutline = true
}

object Img {
    /** Decodes with the largest power-of-two sampling that still keeps the result >= maxW x maxH (low RAM). */
    fun decode(open: () -> InputStream?, maxW: Int, maxH: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        open()?.use { BitmapFactory.decodeStream(it, null, o) }
        var s = 1
        while (o.outWidth / (s * 2) >= maxW && o.outHeight / (s * 2) >= maxH) s *= 2
        val d = BitmapFactory.Options().apply { inSampleSize = s }
        return open()?.use { BitmapFactory.decodeStream(it, null, d) }
    }

    fun saveWallpaper(ctx: Context, uri: Uri, out: File) {
        val b = decode({ ctx.contentResolver.openInputStream(uri) }, 1920, 1080) ?: error("decode failed")
        val s = if (b.width > 1920) Bitmap.createScaledBitmap(b, 1920, b.height * 1920 / b.width, true) else b
        out.outputStream().use { s.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    }

    fun saveLogo(ctx: Context, uri: Uri, out: File) {
        val b = decode({ ctx.contentResolver.openInputStream(uri) }, 256, 256) ?: error("decode failed")
        val side = minOf(b.width, b.height)
        val sq = Bitmap.createBitmap(b, (b.width - side) / 2, (b.height - side) / 2, side, side)
        val s = Bitmap.createScaledBitmap(sq, 256, 256, true)
        out.outputStream().use { s.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
