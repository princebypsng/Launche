package com.sleek.launcher

import android.content.Context
import android.content.SharedPreferences

class Prefs(ctx: Context) {
    private val sp: SharedPreferences = ctx.getSharedPreferences("sleek", Context.MODE_PRIVATE)
    private fun put(f: (SharedPreferences.Editor) -> Unit) { val e = sp.edit(); f(e); e.apply() }

    var wallpaper: Int get() = sp.getInt("wp", 0); set(v) = put { it.putInt("wp", v) }            // -1 = custom photo
    var dim: Int get() = sp.getInt("dim", 40); set(v) = put { it.putInt("dim", v) }
    var accent: Int get() = sp.getInt("accent", 0); set(v) = put { it.putInt("accent", v) }
    var clock: Int get() = sp.getInt("clock", 0); set(v) = put { it.putInt("clock", v) }          // 0 auto, 1 12h, 2 24h
    var uiSize: Int get() = sp.getInt("ui", 1); set(v) = put { it.putInt("ui", v) }               // 0 small, 1 default, 2 large
    var cardSize: Int get() = sp.getInt("card", 1); set(v) = put { it.putInt("card", v) }
    var showNames: Boolean get() = sp.getBoolean("names", true); set(v) = put { it.putBoolean("names", v) }
    var showNonTv: Boolean get() = sp.getBoolean("nontv", true); set(v) = put { it.putBoolean("nontv", v) }
    var name: String get() = sp.getString("name", "") ?: ""; set(v) = put { it.putString("name", v) }

    val favorites: Set<String> get() = HashSet(sp.getStringSet("fav", emptySet()) ?: emptySet())
    val recent: List<String> get() = (sp.getString("recent", "") ?: "").split("|").filter { it.isNotEmpty() }

    fun toggleFavorite(key: String) {
        val s = favorites.toMutableSet()
        if (!s.remove(key)) s.add(key)
        put { it.putStringSet("fav", s) }
    }

    fun pushRecent(key: String) {
        val l = recent.toMutableList()
        l.remove(key); l.add(0, key)
        put { it.putString("recent", l.take(12).joinToString("|")) }
    }
}
